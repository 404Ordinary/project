#include "mytcpserver.h"
#include <QDebug>
#include "mytcpsocket.h"
MyTcpServer::MyTcpServer() {}

//单例模式，确保 MyTcpServer 类只有一个实例，并提供了一个全局访问点来获取该实例
MyTcpServer &MyTcpServer::getInstance()
{
    static MyTcpServer instance;
    return instance;
}


//qintptr socketDescriptor 是一个表示客户端连接的唯一标识符。
//每当有新的客户端连接到服务器时，操作系统会为该连接分配一个 socketDescriptor，
//这个标识符可以用来与该连接进行通信。
void MyTcpServer::incomingConnection(qintptr socketDescriptor)
{
    qDebug()<<"new client connected";
    MyTcpSocket *pTcpSocket=new MyTcpSocket;
    //socketDescriptor 是在客户端连接时由操作系统分配的一个唯一标识符，
    //它允许 MyTcpSocket 对象通过这个描述符与客户端进行通信。
    pTcpSocket->setSocketDescriptor(socketDescriptor);
    connect(pTcpSocket,&MyTcpSocket::loginSuccess,this,[=](){
        //append(pTcpSocket) 将新创建的 pTcpSocket 对象指针添加到 m_tcpSocketList 中。
        //保持对所有活跃连接的追踪
        m_tcpSocketList.append(pTcpSocket);
        qDebug()<<"开始加入新用户的socket";
        qDebug()<<pTcpSocket->getName();
    });

    connect(pTcpSocket,SIGNAL(offline(MyTcpSocket*)),this,SLOT(deleteSocket(MyTcpSocket*)));
}

void MyTcpServer::resend(const char *wantPerson, PDU *pdu)
{
    if(wantPerson==NULL||pdu==NULL)
    {
        return;
    }

    QString strName=wantPerson;
    for(int i=0;i<m_tcpSocketList.size();i++)
    {
        if(strName==m_tcpSocketList.at(i)->getName())
        {
            m_tcpSocketList.at(i)->write((char *)pdu,pdu->uiPDULen);
            break;
        }
    }

}

void MyTcpServer::deleteSocket(MyTcpSocket *mysocket)
{   //iter 是一个指向 QList<MyTcpSocket*> 中元素的迭代器。
    //m_tcpSocketList.begin() 获取列表的第一个元素的迭代器，遍历从头开始。
    //m_tcpSocketList.end() 是列表的尾部迭代器，表示容器的结束位置。
    QList<MyTcpSocket*>::iterator iter=m_tcpSocketList.begin();
    for(;iter!=m_tcpSocketList.end();iter++)
    {
        if(mysocket==*iter)
        {
            delete *iter;
            //(*iter) -> deleteLater();//使用delete *iter时，多开客户端时，关闭某一个客户端后，服务器会立刻崩溃
            *iter=NULL;
            m_tcpSocketList.erase(iter);
            break;
        }
    }

    for(int i=0;i<m_tcpSocketList.size();i++)
    {
        qDebug()<<m_tcpSocketList.at(i)->getName();
    }
}
