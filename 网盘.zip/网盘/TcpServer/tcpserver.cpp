#include "tcpserver.h"
#include "ui_tcpserver.h"
#include "mytcpserver.h"
#include <QByteArray>
#include <QDebug>
#include <QMessageBox>
#include <QHostAddress>
#include <QFile>
TcpServer::TcpServer(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::TcpServer)
{
    ui->setupUi(this);
    loadConfig();
    MyTcpServer::getInstance().listen(QHostAddress(m_strIP),m_usPort);
}
void  TcpServer::loadConfig()
{
    QFile file(":/server.config");
    if(file.open(QIODevice::ReadOnly))
    {
        QByteArray baData=file.readAll();
        QString strData=baData.toStdString().c_str();
        file.close();
        strData.replace("\r\n"," ");//  把\r\n用空格替换掉
        QStringList strList=strData.split(" ");//把字符串以空格分割存储到字符串数组strList中
        m_strIP=strList.at(0);
        m_usPort=strList.at(1).toUShort();
        qDebug()<<"ip:"<<m_strIP<<"port:"<<m_usPort;

    }
    else
    {
        QMessageBox::critical(this,"open config","open config failed");
    }
}

TcpServer::~TcpServer()
{
    delete ui;
}
