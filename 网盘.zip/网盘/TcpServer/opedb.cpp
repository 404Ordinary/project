#include "opedb.h"
#include <QSqlError>
#include <QMessageBox>
#include <QString>
#include <QDebug>
OpeDB::OpeDB(QObject *parent)
    : QObject{parent}
{
    m_db=QSqlDatabase::addDatabase("QSQLITE");
    init();
}

OpeDB &OpeDB::getInstance()
{
    static OpeDB instance;
    return instance;
}

void OpeDB::init()
{
    m_db.setHostName("loscalhost");  //连接远程数据库为地址
    m_db.setDatabaseName("D:\\YUN\\TcpServer\\cloud.db");
    if (m_db.open())
    {
        QSqlQuery query;
        query.exec("select * from usrInfo");
        while (query.next())
        {
            QString data = QString("%1,%2,%3").arg(query.value(0).toString()).arg(query.value(1).toString()).arg(query.value(2).toString());
            qDebug() << data;
        }
    }
    else
    {
        QMessageBox::critical(NULL, "打开数据库","打开数据库失败");
    }
}

OpeDB::~OpeDB()
{
    m_db.close();
}

bool OpeDB::handleRegist(const char *name, const char *pwd)
{
    if(NULL==name||NULL==pwd)
    {
        return false;
    }
    QString data=QString("insert into usrInfo(name,pwd) values(\'%1\',\'%2\')").arg(name).arg(pwd);
    QSqlQuery query;
    return query.exec(data);
}

bool OpeDB::handleLogin(const char *name, const char *pwd)
{
    if(NULL==name||NULL==pwd)
    {
        return false;
    }
    QString data=QString("select * from usrInfo where name=\'%1\' and pwd=\'%2\' and online=0").arg(name).arg(pwd);
    QSqlQuery query;
    query.exec(data);//exec() 返回一个布尔值，指示 SQL 语句是否成功执行
    //query.next() 用于将查询结果指针移动到下一行记录，并检查是否还有更多的记录。
    //每次调用 next() 时，它会将结果集的指针向下移动一行，返回 true 如果还有更多的记录，返回 false 如果已经到达结果集的末尾。
    if(query.next())
    {
        data=QString("UPDATE usrInfo SET online = 1 WHERE name = \'%1\';").arg(name);
        QSqlQuery query;
        query.exec(data);
        return true;
    }
    else
    {
        return false;
    }
}

void OpeDB::handlOffline(const char *name)
{
    if(NULL==name)
    {
        return;
    }
    qDebug()<<"用户即将下线...";
    QString data=QString("UPDATE usrInfo SET online = 0 WHERE name = %1;").arg(name);
    QSqlQuery query;
    query.exec(data);
}

QStringList OpeDB::handAllOnline()
{
    QString data=QString("select name from usrInfo where online=1;");
    qDebug()<<"查询在线用户的sql语句："<<data;
    QSqlQuery query;
    query.exec(data);
    QStringList result;
    result.clear();

    while(query.next())
    {
        result.append(query.value(0).toString());
    }
    return result;
}

int OpeDB::handleSearchUsr(const char *name)
{
    if(name==NULL)
    {return -1;}
    QString data=QString("select online from usrInfo where name=\'%1\'").arg(name);
    QSqlQuery query;
    query.exec(data);
    if(query.next())
    {
        int ret=query.value(0).toInt();
        if(ret==1)
        {
            return 1;
        }
        else if(ret==0)
        {
            return 0;
        }
    }
    else
    {
        return -1;
    }
}

int OpeDB::handleAddFriend(const char *wantPerson,const char *loginPerson)
{
    if(NULL == wantPerson || NULL == loginPerson)
    {
        // 输入内容格式错误
        return -1;
    }
    QString data = QString("select * from friend where (id=(select id from usrInfo where name=\'%1\') "
                            "and friendId =(select id from usrInfo where name=\'%2\')) "
                            "or (friendId=(select id from usrInfo where name=\'%3\') "
                            "and id=(select id from usrInfo where name=\'%4\'))")
                         .arg(wantPerson).arg(loginPerson).arg(wantPerson).arg(loginPerson);
    //qDebug()<<data;
    QSqlQuery query;
    query.exec(data);
    if(query.next())
    {
        return -1;//查询到好友表中有数据，表示已经是好友
    }
    else
    {
        //不是好友，再看是否在线，在线才允许添加
        data=QString("select online from usrInfo where name=\'%1\'").arg(wantPerson);
        // 执行查询
        if (!query.exec(data)) {
            // 查询执行失败，输出错误信息
            qDebug() << "查询执行失败：" << query.lastError().text();

        }

        int ret;
        if (query.next()) {
            // 获取查询结果并转换为整数
            ret = query.value(0).toInt();
            qDebug() << "在线状态为：" << ret;
        }

        if(ret==0)
        {
            return 0;
        }
        else
        {
            return 1;
        }

    }

}

int OpeDB::addFriend(const char *wantPerson, const char *loginPerson)
{
    QSqlQuery query;
    qDebug()<<"wantPerson:"<<wantPerson;
    qDebug()<<"loginPerson"<<loginPerson;
    QString  data=QString("select id from usrInfo where name=\'%1\'").arg(loginPerson);
    query.exec(data);
    query.next();
    int id = query.value(0).toInt();
    qDebug()<<"id:"<<id;

    data=QString("select id from usrInfo where name=\'%1\'").arg(wantPerson);
    query.exec(data);
    query.next();
    int friendid = query.value(0).toInt();
    qDebug()<<"friendid:"<<friendid;

    data=QString("INSERT INTO friend(id, friendId) VALUES (\'%1\', \'%2\')").arg(id).arg(friendid);
    if (query.exec(data)) {
        qDebug()<<"数据库添加好友成功。。。";
        return 1;
    } else {
        // 插入失败
        return 0;
    }
}

QStringList OpeDB::handleFlushFriend(const char *name)
{
    QStringList strFriendList;
    strFriendList.clear();
    if(name==NULL)
    {
        return strFriendList;
    }

    QString data=QString("select name from usrInfo where "
                           "id in(select id from friend where "
                           "friendId=(select id from usrInfo where "
                           "name=\'%1\')) and online=1").arg(name);
    qDebug()<<data;
    QSqlQuery query;
    query.exec(data);
    while(query.next())
    {
        strFriendList.append(query.value(0).toString());
    }

    data=QString("select name from usrInfo where "
                           "id in (select friendId from friend where "
                           "id=(select id from usrInfo where "
                           "name=\'%1\'))  and online=1").arg(name);
    query.exec(data);
    while(query.next())
    {
        strFriendList.append(query.value(0).toString());
    }
    return strFriendList;
}

bool OpeDB::handleDeleteFriend(const char *friendName, const char *loginName)
{
    if(friendName==NULL||loginName==NULL)
    {
        return false;
    }
    QString data=QString("delete from friend where "
                           "id=(select id from usrInfo where name=\'%1\') "
                           "and friendId=(select id from usrInfo where name=\'%2\')").arg(loginName).arg(friendName);
    qDebug()<<data;
    QSqlQuery query;
    query.exec(data);

    data=QString("delete from friend where "
                   "id=(select id from usrInfo where name=\'%1\') "
                   "and friendId=(select id from usrInfo where name=\'%2\')").arg(friendName).arg(loginName);
    query.exec(data);
    return true;
}
