#include "privatechat.h"
#include "ui_privatechat.h"
#include "QMessageBox"
#include "QString"
#include "tcpclient.h"
#include "protocol.h"
PrivateChat::PrivateChat(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::PrivateChat)
{
    ui->setupUi(this);
    this->setWindowTitle(m_strLoginName+"的聊天窗口");
}

PrivateChat::~PrivateChat()
{
    delete ui;
}

PrivateChat &PrivateChat::getInstance()
{
    static PrivateChat instance;
    return instance;
}



void PrivateChat::setChatName(QString strName)
{
    m_strChatName=strName;
    m_strLoginName=TcpClient::getInstance().loginName();
}

void PrivateChat::updateMsg(const PDU *pdu)
{
    if(pdu==NULL)
    {
        return;
    }
    char sendName[32]={'\0'};
    memcpy(sendName,pdu->caData,32);
    QString strMsg=QString("%1 说: %2").arg(sendName).arg((char*)(pdu->caMSg));
    PrivateChat::getInstance().show();
    ui->showMsg_le->append(strMsg);
}

void PrivateChat::on_sendMsg_pb_clicked()
{
    QString strMsg=ui->inputMsg_le->text();
    ui->inputMsg_le->clear();
    if(!strMsg.isEmpty())
    {
        //+1是因为转为char后需要多一个 \0结束符
        PDU *pdu=mkPDU(strMsg.size()+1);
        pdu->uiMsgType=ENUM_MSG_TYPE_PRIVATE_CHAT_REQUEST;
        //memcpy（Memory Copy）是一个用于内存块复制的函数。
        //它从源地址复制指定字节数的内容到目标地址，适用于任意类型的数据（如数组、结构体等）。
        qDebug()<<"m_strLoginName:"<< m_strLoginName;
        qDebug()<< "m_strChatName:"<<m_strChatName;
        strncpy(pdu->caData,m_strLoginName.toStdString().c_str(),32);
        strncpy(pdu->caData+32,m_strChatName.toStdString().c_str(),32);
        qDebug()<<"caData："<<pdu->caData;
        strncpy((char *)(pdu->caMSg),strMsg.toUtf8().constData(),strMsg.toUtf8().size());
        qDebug()<<"caMsg："<<(char *)pdu->caMSg;
        QString strMsg=QString("%1 说: %2").arg(m_strLoginName).arg((char*)(pdu->caMSg));
        ui->showMsg_le->append(strMsg);
        TcpClient::getInstance().getTcpSocket().write((char *)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;
    }
    else
    {
        QMessageBox::information(this,"发送消息","发送的消息不能为空");
    }
}

