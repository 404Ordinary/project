 #include "tcpclient.h"
#include "ui_tcpclient.h"
#include <QByteArray>
#include <QDebug>
#include <QMessageBox>
#include <QHostAddress>
#include "privatechat.h"
TcpClient::TcpClient(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::TcpClient)
{
    ui->setupUi(this);
    loadConfig();

    qDebug()<<m_strIP<<m_usPort;
    //连接服务器
    m_tcpSocket.connectToHost(QHostAddress(m_strIP),m_usPort);

    connect(&m_tcpSocket,SIGNAL(connected()),this,SLOT(showConnect()));

    connect(&m_tcpSocket,SIGNAL(readyRead()),this,SLOT(recvMsg()));


}

TcpClient::~TcpClient()
{
    delete ui;
}

void TcpClient::loadConfig()
{
    QFile file(":/client.config");
    if(file.open(QIODevice::ReadOnly))
    {
        QByteArray baData=file.readAll();
        //c_str() 是 std::string 类型的成员函数，
        //它返回一个指向 std::string 内部数据的常量字符指针（const char*）
        //该指针指向一个以 '\0' 结尾的 C 风格字符串
        QString strData=baData.toStdString().c_str();
        file.close();
        strData.replace("\r\n"," ");//  把\r\n用空格替换掉
        QStringList strList=strData.split(" ");//把字符串以空格分割存储到字符串数组strList中
        m_strIP=strList.at(0);
        m_usPort=strList.at(1).toUShort();
        qDebug()<<"ip:"<<m_strIP<<"port:"<<m_usPort;

    }
    else
    {
        QMessageBox::critical(this,"open config","open config failed");
    }
}

TcpClient &TcpClient::getInstance()
{
    static TcpClient instance;
    return instance;
}

QTcpSocket &TcpClient::getTcpSocket()
{
    return m_tcpSocket;
}

QString TcpClient::loginName()
{
    return m_strLoginName;
}

QString TcpClient::curPath()
{
    return m_strCurPath;
}

void TcpClient::setCurPath(QString strCurPath)
{
    m_strCurPath=strCurPath;
}

void TcpClient::showConnect()
{
    QMessageBox::information(this,"连接服务器","连接服务器成功");
}

void TcpClient::recvMsg()
{

    if(OpeWidget::getInstance().getBook()->getDownLoadStatus())
    {
        QByteArray buffer=m_tcpSocket.readAll();
        m_file.write(buffer);
        qDebug()<<"本次接受数据的大小："<<buffer.size();
        Book *pBook=OpeWidget::getInstance().getBook();
        pBook->m_iRecved+=buffer.size();
        qDebug()<<"已经接收接收数据的大小："<<pBook->m_iRecved;
        if(pBook->m_iTotal==pBook->m_iRecved)
        {
            m_file.close();
            pBook->m_iTotal=0;
            pBook->m_iRecved=0;
            pBook->setDownLoadStatus(false);
            QMessageBox::information(this,"下载文件","下载文件完成");
        }
        else if(pBook->m_iTotal < pBook->m_iRecved)
        {
            m_file.close();
            pBook->m_iTotal=0;
            pBook->m_iRecved=0;
            pBook->setDownLoadStatus(false);
            QMessageBox::critical(this,"下载文件","下载文件失败！！！");
        }
        return;
    }
    //m_tcpSocket->bytesAvailable() 返回当前套接字（即 MyTcpSocket 类实例）中可以读取的数据字节数
    qDebug()<<"传输数据的总字节数："<<m_tcpSocket.bytesAvailable();
    uint uiPDULen=0;
    //从套接字中读取 sizeof(uint) 字节的数据并将其存储到 uiPDULen 中，
    //通常这部分数据是 PDU 的总长度（包括头部）。
    m_tcpSocket.read((char*)&uiPDULen,sizeof(uint));
    uint uiMsgLen=uiPDULen-sizeof(PDU);
    PDU *pdu=mkPDU(uiMsgLen);
    //char*)pdu + sizeof(uint) 将 pdu 指针偏移到数据部分的位置
    //uiPDULen - sizeof(uint) 表示要读取的数据字节数，是剩余的消息数据部分（去掉头部长度字段后的部分）
    m_tcpSocket.read((char*)pdu+sizeof(uint),uiPDULen-sizeof(uint));

    //判断消息类型
    switch (pdu->uiMsgType) {
    case ENUM_MSG_TYPE_RESGIST_RESPOND:
    {
        //strcmp() 函数来比较 pdu->caData 和 REGIST_OK 两个字符串是否相同。
        //如果两个字符串完全相同，strcmp() 返回 0。
        //如果字符串 str1 在字典顺序中小于 str2，则返回一个负值；
        //如果 str1 在字典顺序中大于 str2，则返回一个正值
        if(strcmp(pdu->caData,REGIST_OK)==0)
        {
            QMessageBox::information(this,"注册","注册成功！！！");
        }
        else if(strcmp(pdu->caData,REGIST_FAILED)==0)
        {
            QMessageBox::warning(this,"注册","注册失败！！！");
        }
        break;
    }

    case ENUM_MSG_TYPE_LOGIN_RESPOND:
    {
        if(strcmp(pdu->caData,LOGIN_OK)==0)
        {
            m_strCurPath=QString("./%1").arg(m_strLoginName);
            //qDebug()<<"登录成功,当前路径："<<m_strCurPath;
            QMessageBox::information(this,"登录","登录成功！！！");
            OpeWidget::getInstance().setWindowTitle("你好,"+loginName());
            OpeWidget::getInstance().show();
            this->hide();

            OpeWidget::getInstance().getBook()->getFlushDirPB()->click();

            //需要添加延时后再触发刷新按钮，否则连着发送后面刷新不了
            QTimer::singleShot(50, []() {
                OpeWidget::getInstance().getFriend()->getFlushFriend()->click();
            });

        }
        else if(strcmp(pdu->caData,LOGIN_FAILED)==0)
        {
            QMessageBox::warning(this,"登录","登录失败，用户名或密码错误或重复登录");
        }
        break;
    }
    case ENUM_MSG_TYPE_ALL_ONLINE_RESPOND:
    {
        OpeWidget::getInstance().getFriend()->showAllOnlineUsr(pdu);

        break;
    }

    case ENUM_MSG_TYPE_SEACH_USR_RESPOND:
    {
        if(strcmp(pdu->caData,SEARCH_USR_ONLINE)==0)
        {
            QMessageBox::information(this,"搜索",QString("%1: online")
                        .arg(OpeWidget::getInstance().getFriend()->m_strSeachName));
        }
        else if(strcmp(pdu->caData,SEARCH_USR_OFFONLINE)==0)
        {
            QMessageBox::information(this,"搜索",QString("%1: offoline")
                        .arg(OpeWidget::getInstance().getFriend()->m_strSeachName));
        }
        else if(strcmp(pdu->caData,SEARCH_USR_NO)==0)
        {
            QMessageBox::information(this,"搜索",QString("%1: not exist")
                        .arg(OpeWidget::getInstance().getFriend()->m_strSeachName));
        }
        break;
    }

    case ENUM_MSG_TYPE_ADD_FRIEND_RESPOND:
    {
        qDebug()<<"客户端添加好友响应";
        QMessageBox::information(this,"添加好友",pdu->caData);

        //需要添加延时后再触发刷新按钮，否则连着发送后面刷新不了
        QTimer::singleShot(50, []() {
            OpeWidget::getInstance().getFriend()->getFlushFriend()->click();
        });
        break;
    }

    case ENUM_MSG_TYPE_ADD_FRIEND_REQUEST:
    {
        char loginName[32]={'\0'};
        strncpy(loginName,pdu->caData+32,32);
        int ret=QMessageBox::information(this,"添加好友",QString("%1 want to add you as friend?").arg(loginName),
                                 QMessageBox::Yes,QMessageBox::No);
        PDU *respdu=mkPDU(0);
        memcpy(respdu->caData,pdu->caData,64);
        if(ret==QMessageBox::Yes)
        {
            respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_AGREE;
            qDebug()<<"同意";
        }
        if(ret==QMessageBox::No)
        {
            respdu->uiMsgType=ENUM_MSG_TYPE_ADD_FRIEND_REFUSE;
            qDebug()<<"不同意";
        }
        qDebug()<<"respdu->uiMsgType:"<<respdu->uiMsgType;
        m_tcpSocket.write((char *)respdu,respdu->uiPDULen);
        free(respdu);
        respdu=NULL;
        break;
    }

    case ENUM_MSG_TYPE_ADD_FRIEND_REFUSE:
    {
        QMessageBox::warning(this,"添加好友","对方拒绝你的好友申请！");
        break;
    }

    case ENUM_MSG_TYPE_FLUSH_FRIEND_RESPOND:
        {
        OpeWidget::getInstance().getFriend()->updateFriendList(pdu);
        break;
        }

    case ENUM_MSG_TYPE_DELETE_FRIEND_REQUEST:
        {
            char name[32];
            memcpy(name,pdu->caData,32);
            QMessageBox::information(this,"删除好友",QString("%1 删除你作为他的好友").arg(name));

            //需要添加延时后再触发刷新按钮，否则连着发送后面刷新不了
            QTimer::singleShot(50, []() {
                OpeWidget::getInstance().getFriend()->getFlushFriend()->click();
            });

            break;
        }
    case ENUM_MSG_TYPE_DELETE_FRIEND_RESPOND:
        {
        QMessageBox::information(this,"删除好友","删除好友成功！");

        //需要添加延时后再触发刷新按钮，否则连着发送后面刷新不了
        QTimer::singleShot(50, []() {
            OpeWidget::getInstance().getFriend()->getFlushFriend()->click();
        });

        break;
        }

    case ENUM_MSG_TYPE_PRIVATE_CHAT_REQUEST:
        {
            if(PrivateChat::getInstance().isHidden())
            {
            PrivateChat::getInstance().setWindowTitle(TcpClient::getInstance().loginName()+"的聊天窗口");
            PrivateChat::getInstance().show();
            }
            char sendName[32]={'\0'};
            memcpy(sendName,pdu->caData,32);
             QString strName=sendName;
            PrivateChat::getInstance().setChatName(strName);
            PrivateChat::getInstance().updateMsg(pdu);
            break;
        }

    case ENUM_MSG_TYPE_GROUP_CHAT_REQUEST:
        {
            OpeWidget::getInstance().getFriend()->updateGroupMsg(pdu);
            break;
        }

    case ENUM_MSG_TYPE_CREATE_DIR_RESPOND:
        {
        QMessageBox::information(this,"创建文件夹",pdu->caData);
        OpeWidget::getInstance().getBook()->getFlushDirPB()->click();
        break;
        }

    case ENUM_MSG_TYPE_FLUSH_FILE_RESPOND:
        {
            OpeWidget::getInstance().getBook()->updateFileList(pdu);
            break;
        }

    case ENUM_MSG_TYPE_DEL_DIR_RESPOND:
        {
            //OpeWidget::getInstance().getBook()->delSelectFile();
            QMessageBox::information(this,"删除文件夹",pdu->caData);
            OpeWidget::getInstance().getBook()->getFlushDirPB()->click();
            break;
        }

    case ENUM_MSG_TYPE_RENAME_DIR_RESPOND:
        {
        QMessageBox::information(this,"重命名文件",pdu->caData);
        OpeWidget::getInstance().getBook()->getFlushDirPB()->click();
        break;
        }

    case ENUM_MSG_TYPE_ENTER_DIR_RESPOND:
    {
        char strDirName[32]={"\0"};
        strncpy(strDirName,pdu->caData,32);
        m_strCurPath=m_strCurPath+QString("/%1").arg(strDirName);
        qDebug()<<"当前路径："<< m_strCurPath;
        OpeWidget::getInstance().getBook()->updateFileList(pdu);
        //QMessageBox::information(this,"进入文件夹","进入文件夹成功！");
        break;
    }

    case ENUM_MSG_TYPE_UPLOAD_FILE_RESPOND:
    {
        QMessageBox::information(this,"上传文件",pdu->caData);
        OpeWidget::getInstance().getBook()->getFlushDirPB()->click();
        break;
    }

    case ENUM_MSG_TYPE_DOWNLOAD_FILE_RESPOND:
    {
        qDebug()<<pdu->caData;
        char fileName[32]={'\0'};
        sscanf(pdu->caData,"%s %lld",fileName,&(OpeWidget::getInstance().getBook()->m_iTotal));
        qDebug()<<"接受下载文件的大小："<<OpeWidget::getInstance().getBook()->m_iTotal;
        if(strlen(fileName)&&OpeWidget::getInstance().getBook()->m_iTotal>0)
        {
            OpeWidget::getInstance().getBook()->setDownLoadStatus(true);
            m_file.setFileName(OpeWidget::getInstance().getBook()->getSaveFilePath());
            if(!m_file.open(QIODevice::WriteOnly))
            {
                QMessageBox::warning(this,"下载文件","获取保存文件的路径失败");
            }
        }
        break;
    }

    case ENUM_MSG_TYPE_SHARE_FILE_RESPOND:
    {
        QMessageBox::information(this, "分享文件", pdu->caData);
        break;
    }

    case ENUM_MSG_TYPE_SHARE_FILE_NOTE:
    {
        qDebug() << "开始准备接受文件";
        char *pPath = new char[pdu->uiMsgLen];
        memcpy(pPath, (char*)pdu->caMSg, pdu->uiMsgLen);
        // aa/bb/cc/a.txt
        qDebug() << pPath;
        char *pos = strrchr(pPath, '/'); //找到最后一个 / 出现的位置
        qDebug() << pos;
        if(NULL != pos)
        {
            pos++; // 向右移动一位，因为 / 这个字符我们不需要，只需要文件名称，即a.txt
            QString strNote = QString("%1 share file -> %2\n do you accecpt").arg(pdu->caData).arg(pos);
            int ret = QMessageBox::question(this, "共享文件", strNote);
            if(QMessageBox::Yes == ret)
            {
                PDU *retPdu = mkPDU(pdu->uiMsgLen);
                retPdu->uiMsgType = ENUM_MSG_TYPE_SHARE_FILE_NOTE_REQUEST;
                memcpy(retPdu->caMSg, pdu->caMSg, pdu->uiMsgLen);
                QString strName = TcpClient::getInstance().loginName();
                strcpy(retPdu->caData, strName.toStdString().c_str());
                m_tcpSocket.write((char*)retPdu,retPdu->uiPDULen);
            }
        }

        break;
    }

    case ENUM_MSG_TYPE_MOVE_FILE_RESPOND:
    {
        QMessageBox::information(this,"分享文件",pdu->caData);

        //3秒后自动刷新，还没有实现接受文件完毕后刷新
        QTimer::singleShot(3000, []() {
            OpeWidget::getInstance().getFriend()->getFlushFriend()->click();
        });
        break;
    }

    default:
    break;
    }


    free(pdu);
    pdu=NULL;

}

/*
void TcpClient::on_sendBtn_clicked()
{
    QString strMsg=ui->lineEdit->text();
    if(!strMsg.isEmpty())
    {
        PDU *pdu=mkPDU(strMsg.size());
        pdu->uiMsgType=8888;
        //将 strMsg 字符串（经过转换为 C 风格字符串）的内容，按字节复制到 pdu 结构体中的 caData 数组。
        //复制的字节数是 strMsg 的字符数（strMsg.size()）。
        memcpy(pdu->caMSg,strMsg.toStdString().c_str(),strMsg.size());

        qDebug()<<"客户端发往服务器的数据："<<(char *)(pdu->caMSg);
        //第一个参数：待写入的数据，以字节流的形式传输。  第二个参数：待写入数据的大小（字节数）。
        m_tcpSocket.write((char *)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;
    }
    else
    {
        QMessageBox::warning(this,"信息发送","发送的信息不能为空！");
    }
}
*/

void TcpClient::on_login_btn_clicked()
{
    QString strName=ui->name_le->text();
    QString strPwd=ui->pwd_le->text();
    if(!strName.isEmpty()&&!strPwd.isEmpty())
    {
        //还未登成功，先把登录名存储起来
        m_strLoginName=strName;
        qDebug()<<"点击登录按钮中的登录名："<<m_strLoginName;
        PDU *pdu=mkPDU(0);
        pdu->uiMsgType=ENUM_MSG_TYPE_LOGIN_REQUEST;
        strncpy(pdu->caData,strName.toStdString().c_str(),32);
        strncpy(pdu->caData+32,strPwd.toStdString().c_str(),32);
        m_tcpSocket.write((char *)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;
    }
    else
    {
        QMessageBox::warning(this,"登录提示","用户名或密码为空！！！");
    }
}

void TcpClient::on_regiest_btn_clicked()
{
    QString strName=ui->name_le->text();
    QString strPwd=ui->pwd_le->text();
    if(!strName.isEmpty()&&!strPwd.isEmpty())
    {
        PDU *pdu=mkPDU(0);
        pdu->uiMsgType=ENUM_MSG_TYPE_RESGIST_REQUEST;
        strncpy(pdu->caData,strName.toStdString().c_str(),32);
        strncpy(pdu->caData+32,strPwd.toStdString().c_str(),32);
        m_tcpSocket.write((char *)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;
    }
    else
    {
        QMessageBox::warning(this,"注册提示","用户名或密码为空！！！");
    }
}

void TcpClient::on_cancel_btn_clicked()
{

}

