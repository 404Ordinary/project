#include "friend.h"
#include <protocol.h>
#include "tcpclient.h"
#include <QInputDialog>
#include <QDebug>
#include <QMessageBox>
#include <privatechat.h>
Friend::Friend(QWidget *parent)
    : QWidget{parent}
{
    m_pShowMsgTE=new QTextEdit;
    m_pFriendListWidget=new QListWidget;
    m_pInputMsgLE=new QLineEdit;

    m_pDelFriendPB=new QPushButton("删除好友");
    m_pFlushFriendPB=new QPushButton("刷新在线好友");
    m_pShowOnlineUsrPB=new QPushButton("显示在线用户");
    m_pSearchUsrPB=new QPushButton("查找用户");
    m_pMsgSendPB=new QPushButton("群聊发送");
    m_pPrivateChatPB=new QPushButton("私聊");

    QVBoxLayout *pRightPBVBL = new QVBoxLayout;
    pRightPBVBL->addWidget(m_pDelFriendPB);
    pRightPBVBL->addWidget(m_pFlushFriendPB);
    pRightPBVBL->addWidget(m_pShowOnlineUsrPB);
    pRightPBVBL->addWidget(m_pSearchUsrPB);
    pRightPBVBL->addWidget(m_pPrivateChatPB);

    QHBoxLayout *pTopHBL=new QHBoxLayout;
    pTopHBL->addWidget(m_pShowMsgTE);
    pTopHBL->addWidget(m_pFriendListWidget);
    pTopHBL->addLayout(pRightPBVBL);


    QHBoxLayout *pMsgHBL = new QHBoxLayout;
    pMsgHBL->addWidget(m_pInputMsgLE);
    pMsgHBL->addWidget(m_pMsgSendPB);

    m_pOnline=new Online();

    QVBoxLayout *pMain = new QVBoxLayout;
    pMain->addLayout(pTopHBL);
    pMain->addLayout(pMsgHBL);
    pMain->addWidget(m_pOnline);


    // 显示该布局
    setLayout(pMain);
    m_pOnline->hide();

    connect(m_pShowOnlineUsrPB,SIGNAL(clicked(bool)),this,SLOT(showOnline()));

    connect(m_pSearchUsrPB,SIGNAL(clicked(bool)),this,SLOT(searchUsr()));
    connect(m_pFlushFriendPB,SIGNAL(clicked(bool)),this,SLOT(flushFriend()));
    connect(m_pDelFriendPB,SIGNAL(clicked(bool)),this,SLOT(deleteFriend()));
    connect(m_pPrivateChatPB,SIGNAL(clicked(bool)),this,SLOT(privateChat()));
    connect(m_pMsgSendPB,SIGNAL(clicked(bool)),this,SLOT(groupChat()));
    qDebug()<<"firend.cpp正在初始化";
}

void Friend:: showAllOnlineUsr(PDU *pdu)
{
    if(pdu==NULL)
    {
        return;
    }
    m_pOnline->showUsr(pdu);
}

void Friend::showOnline()
{
    if(m_pOnline->isHidden())
    {
        m_pOnline->show();
        qDebug()<<"点击了显示在线用户按钮";
        PDU *pdu=mkPDU(0);
        pdu->uiMsgType=ENUM_MSG_TYPE_ALL_ONLINE_REQUEST;
        qDebug()<<"消息长度："<<pdu->uiMsgLen;
        TcpClient::getInstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
        qDebug()<<"发送了显示在线用户的请求";
        free(pdu);
        pdu=NULL;
    }
    else
    {
        m_pOnline->hide();
    }
}

void Friend::searchUsr()
{
    m_strSeachName= QInputDialog::getText(this,"搜索","用户名");
    if(! m_strSeachName.isEmpty())
    {
        PDU *pdu=mkPDU(0);
        pdu->uiMsgType=ENUM_MSG_TYPE_SEACH_USR_REQUEST;
        memcpy(pdu->caData,m_strSeachName.toStdString().c_str(),m_strSeachName.size());
        TcpClient::getInstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
        qDebug()<<"发送了显示搜索用户的请求";
        free(pdu);
        pdu=NULL;
    }

}

void Friend::flushFriend()
{
    QString loginName=TcpClient::getInstance().loginName();
    PDU *pdu=mkPDU(0);
    qDebug()<<"刷新好友中的登录名："<<loginName;
    pdu->uiMsgType=ENUM_MSG_TYPE_FLUSH_FRIEND_REQUEST;
    memcpy(pdu->caData,loginName.toStdString().c_str(),loginName.size());
    qDebug()<<"刷新好友列表中的caData:"<<pdu->caData;
    TcpClient::getInstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
    free(pdu);
    pdu=NULL;
}

void Friend::updateFriendList(PDU *pdu)
{
    if(pdu==NULL)
    {
        return;
    }
    uint uiSize=pdu->uiMsgLen/32;
    char caName[32]={'\0'};
    m_pFriendListWidget->clear();
    for(uint i=0;i<uiSize;i++)
    {
        memcpy(caName,(char *)(pdu->caMSg)+i*32,32);
        m_pFriendListWidget->addItem(caName);
    }
}

void Friend::updateGroupMsg(PDU *pdu)
{
    QString strMsg=QString("%1 说：%2").arg(pdu->caData).arg((char *)pdu->caMSg);
    m_pShowMsgTE->append(strMsg);
}

QPushButton *Friend::getFlushFriend()
{
    return m_pFlushFriendPB;
}

QListWidget *Friend::getFriendList()
{
    return m_pFriendListWidget;
}

void Friend::deleteFriend()
{
    if(m_pFriendListWidget->currentItem()==NULL)
    {
        QMessageBox::information(this,"删除好友","请选择要删除的好友！");
        return;
    }
    QString friendName=m_pFriendListWidget->currentItem()->text();
    PDU *pdu=mkPDU(0);
    pdu->uiMsgType=ENUM_MSG_TYPE_DELETE_FRIEND_REQUEST;
    QString loginName=TcpClient::getInstance().loginName();
    memcpy(pdu->caData,loginName.toStdString().c_str(),loginName.size());
    memcpy(pdu->caData+32,friendName.toStdString().c_str(),friendName.size());
    TcpClient::getInstance().getTcpSocket().write((char*)pdu,pdu->uiPDULen);
    free(pdu);
    pdu=NULL;

    //需要添加延时后再触发刷新按钮，否则连着发送后面刷新不了
    QTimer::singleShot(50, []() {
        OpeWidget::getInstance().getFriend()->getFlushFriend()->click();
    });
}

void Friend::privateChat()
{
    if(m_pFriendListWidget->currentItem()==NULL)
    {
        QMessageBox::information(this,"私聊好友","请选择要私聊的好友！");
        return;
    }

    QString strChatName=m_pFriendListWidget->currentItem()->text();
    PrivateChat::getInstance().setChatName(strChatName);
    PrivateChat::getInstance().setWindowTitle(TcpClient::getInstance().loginName()+"的聊天窗口");
    if(PrivateChat::getInstance().isHidden())
    {
    PrivateChat::getInstance().show();
    }
}

void Friend::groupChat()
{
    QString strMsg=m_pInputMsgLE->text();
    m_pInputMsgLE->clear();
    if(!strMsg.isEmpty())
    {
        PDU *pdu=mkPDU(strMsg.size()+1);
        pdu->uiMsgType=ENUM_MSG_TYPE_GROUP_CHAT_REQUEST;
        QString loginName=TcpClient::getInstance().loginName();
        strncpy(pdu->caData,loginName.toStdString().c_str(),loginName.size());
        strncpy((char *)pdu->caMSg,strMsg.toStdString().c_str(),strMsg.size());
        updateGroupMsg(pdu);
        TcpClient::getInstance().getTcpSocket().write((char *)pdu,pdu->uiPDULen);

    }
    else
    {
        QMessageBox::warning(this,"群聊","发送的消息不能为空");
    }
}
