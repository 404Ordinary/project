#include "tcpclient.h"
#include <QApplication>
#include <QMessageBox>
#include <QDebug>

#include "sharefile.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    TcpClient::getInstance().show();

    // ShareFile w;
    // w.show();
    // TcpClient w;
    // w.show();
    // Friend w;
    // w.show();
    // Online w;
    // w.show();
    // OpeWidget w;
    // w.show();
    return a.exec();
}
