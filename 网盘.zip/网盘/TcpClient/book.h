#ifndef BOOK_H
#define BOOK_H

#include <QWidget>
#include <QListWidget>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <protocol.h>
#include <QTimer>
class Book : public QWidget
{
    Q_OBJECT
public:
    explicit Book(QWidget *parent = nullptr);
    void updateFileList(const PDU *pdu);
    void delSelectFile();
    void setDownLoadStatus(bool status);
    qint64 m_iTotal;
    qint64 m_iRecved=0;
signals:

public slots:
    void createDir();
    void flushFile();
    void delDir();
    void renameDir();
    void enterDir(const QModelIndex &index);
    void returnPre();
    void uploadFile();
    void download();
    bool getDownLoadStatus();
    QString getSaveFilePath();
    QString getShareFileName();

    void uploadFileData();
    QPushButton* getFlushDirPB();

    void shareFile();
    void moveFile();
    void selectDestDir();
private:
    QListWidget *m_pBookListW;
    QPushButton *m_pReturnPB;
    QPushButton *m_pCreateDirPB;
    QPushButton *m_pDelDirPB;
    QPushButton *m_pRenameDirPB;
    QPushButton *m_pFlushDirPB;
    QPushButton *m_pUploadFilePB;
    QPushButton *m_pDelFilePB;
    QPushButton *m_pDownloadFilePB;
    QPushButton *m_pShareFilePB;
    QPushButton *m_pMoveFilePB;
    QPushButton *m_pSelectDirPB;

    QString m_strUploadFilePath;

    //避免粘包，使用定时器
    QTimer *m_pTimer;
    QString m_saveFilePath;
    bool m_bDownLoad;
    QString m_strShareFileName;
    QString m_strMoveFileName;
    QString m_strMoveFilePath;
    QString m_strDestDir;
};

#endif // BOOK_H
