#include "book.h"
#include "protocol.h"
#include "tcpclient.h"
#include "QInputDialog"
#include <QMessageBox>
#include <QFileDialog>
#include <opewidget.h>
#include <sharefile.h>
Book::Book(QWidget *parent)
    : QWidget{parent}
{
    m_pTimer=new QTimer;
    m_bDownLoad=false;
    m_pBookListW = new QListWidget;
    m_pReturnPB = new QPushButton("返回");
    m_pCreateDirPB = new QPushButton("创建文件夹");
    m_pDelDirPB = new QPushButton("删除文件夹");
    m_pRenameDirPB = new QPushButton("重命名文件夹");
    m_pFlushDirPB = new QPushButton("刷新文件夹");
    m_pUploadFilePB = new QPushButton("上传文件");
    m_pDelFilePB = new QPushButton("删除文件");
    m_pDownloadFilePB = new QPushButton("下载文件");
    m_pShareFilePB = new QPushButton("分享文件");
    m_pMoveFilePB = new QPushButton("移动文件");
    m_pSelectDirPB=new QPushButton("目标目录");
    m_pSelectDirPB->setEnabled(false);

    QVBoxLayout *dirLayout = new QVBoxLayout;
    dirLayout->addWidget(m_pReturnPB);
    dirLayout->addWidget(m_pCreateDirPB);
    dirLayout->addWidget(m_pDelDirPB);
    dirLayout->addWidget(m_pRenameDirPB);
    dirLayout->addWidget(m_pFlushDirPB);

    QVBoxLayout *fileLayout = new QVBoxLayout;
    fileLayout->addWidget(m_pUploadFilePB);
    fileLayout->addWidget(m_pDelFilePB);
    fileLayout->addWidget(m_pDownloadFilePB);
    fileLayout->addWidget(m_pShareFilePB);
    fileLayout->addWidget(m_pMoveFilePB);
    fileLayout->addWidget(m_pSelectDirPB);

    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    hBoxLayout->addWidget(m_pBookListW);
    hBoxLayout->addLayout(dirLayout);
    hBoxLayout->addLayout(fileLayout);

    setLayout(hBoxLayout);
    connect(m_pCreateDirPB,SIGNAL(clicked(bool)),this,SLOT(createDir()));
    connect(m_pFlushDirPB,SIGNAL(clicked(bool)),this,SLOT(flushFile()));

    connect(m_pDelDirPB,SIGNAL(clicked(bool)),this,SLOT(delDir()));
    connect(m_pDelFilePB,SIGNAL(clicked(bool)),this,SLOT(delDir()));
    connect(m_pRenameDirPB,SIGNAL(clicked(bool)),this,SLOT(renameDir()));
    //connect(m_pBookListW,SIGNAL(doubleClicked(QModelIndex)), this, SLOT(enterDir(QModelIndex)));
    //上面的qt4语法不会被触发
    connect(m_pBookListW,&QListView::doubleClicked, this,&Book::enterDir);
    connect(m_pReturnPB,&QPushButton::clicked,[=](){returnPre();});
    connect(m_pUploadFilePB,SIGNAL(clicked(bool)),this,SLOT(uploadFile()));
    connect(m_pTimer,SIGNAL(timeout()),this,SLOT(uploadFileData()));
    connect(m_pDownloadFilePB,SIGNAL(clicked(bool)),this,SLOT(download()));
    connect(m_pShareFilePB,SIGNAL(clicked(bool)),this,SLOT(shareFile()));
    connect(m_pMoveFilePB,SIGNAL(clicked(bool)),this,SLOT(moveFile()));
    connect(m_pSelectDirPB,SIGNAL(clicked(bool)),this,SLOT(selectDestDir()));
}

void Book::updateFileList(const PDU *pdu)
{
    if(pdu==NULL)
    {
        return;
    }
    m_pBookListW->clear();
    qDebug()<<"开始刷新文件";
    FileInfo *pFileInfo=NULL;
    int iCount=(pdu->uiMsgLen)/sizeof(FileInfo);
    for(int i=2;i<iCount;i++)
    {
        pFileInfo=(FileInfo *)(pdu->caMSg)+i;
        //qDebug()<<"刷新文件："<<pFileInfo->caFileName<<pFileInfo->iFileType;
        QListWidgetItem *pItem=new QListWidgetItem;
        if(0==pFileInfo->iFileType)
        {
            pItem->setIcon(QIcon(QPixmap(":/map/dir.png")));
        }
        else if(1==pFileInfo->iFileType)
        {
            pItem->setIcon(QIcon(QPixmap(":/map/reg.jpg")));
        }
        pItem->setText(pFileInfo->caFileName);
        m_pBookListW->addItem(pItem);
    }

}

void Book::delSelectFile()
{
    //如果你想删除当前选中的项，可以使用 selectedItems() 来获取所有选中的项，然后逐一删除。
    QList<QListWidgetItem*> selectedItems = m_pBookListW->selectedItems();
    for (QListWidgetItem* item : selectedItems) {
        delete m_pBookListW->takeItem(m_pBookListW->row(item));  // 删除选中的项
    }

}

void Book::setDownLoadStatus(bool status)
{
    m_bDownLoad=status;
}

void Book::createDir()
{
    QString strNewDir=QInputDialog::getText(this,"新建文件夹","新文件夹名字：");
    if(!strNewDir.isEmpty())
    {
        if(strNewDir.size()>32)
        {
            QMessageBox::warning(this,"新建文件夹","新建文件夹名字不能超过32个字符");
            return;
        }
        QString loginName=TcpClient::getInstance().loginName();
        QString curPath=TcpClient::getInstance().curPath();
        PDU *pdu=mkPDU(curPath.size()+1);
        pdu->uiMsgType=ENUM_MSG_TYPE_CREATE_DIR_REQUEST;
        strncpy(pdu->caData,loginName.toStdString().c_str(),loginName.size());
        strncpy(pdu->caData+32,strNewDir.toStdString().c_str(),strNewDir.size());
        strncpy((char *)pdu->caMSg,curPath.toStdString().c_str(),curPath.size());
        TcpClient::getInstance().getTcpSocket().write((char *)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;
    }
    else
    {
        QMessageBox::warning(this,"新建文件夹","新建文件夹名字不能为空");
    }

}

void Book::flushFile()
{
    QString strCurPath=TcpClient::getInstance().curPath();
    PDU *respdu=mkPDU(strCurPath.size()+1);
    respdu->uiMsgType=ENUM_MSG_TYPE_FLUSH_FILE_REQUEST;
    strncpy((char *)respdu->caMSg,strCurPath.toStdString().c_str(),strCurPath.size());
    TcpClient::getInstance().getTcpSocket().write((char *)respdu,respdu->uiPDULen);
    free(respdu);
    respdu=NULL;
}

void Book::delDir()
{
    QString strCurPath=TcpClient::getInstance().curPath();
    QListWidgetItem *pItem=m_pBookListW->currentItem();
    if(pItem==NULL)
    {
        QMessageBox::warning(this,"删除文件","请选择文件后删除");
    }
    else
    {
        QString strDelName=pItem->text();
        PDU *respdu=mkPDU(strCurPath.size()+1);
        respdu->uiMsgType=ENUM_MSG_TYPE_DEL_DIR_REQUEST;
        strncpy(respdu->caData,strDelName.toStdString().c_str(),strDelName.size());
        strncpy((char *)(respdu->caMSg),strCurPath.toStdString().c_str(),strCurPath.size());
        TcpClient::getInstance().getTcpSocket().write((char *)respdu,respdu->uiPDULen);
        free(respdu);
        respdu=NULL;
    }
}

void Book::renameDir()
{
    QString strCurPath=TcpClient::getInstance().curPath();
    QListWidgetItem *pItem=m_pBookListW->currentItem();
    if(pItem==NULL)
    {
        QMessageBox::warning(this,"重命名文件夹","请选择文件夹后再重命名");
    }
    else
    {
        QString strOldName=pItem->text();
        QString strNewName=QInputDialog::getText(this,"重命名文件夹","请输入新文件夹名字：");
        if(strNewName.isEmpty())
        {
            QMessageBox::warning(this,"重命名文件夹","新文件夹名字不能为空");
        }
        else
        {
            PDU *pdu=mkPDU(strCurPath.size());
            pdu->uiMsgType=ENUM_MSG_TYPE_RENAME_DIR_REQUEST;
            strncpy(pdu->caData,strOldName.toStdString().c_str(),strOldName.size());
            strncpy(pdu->caData+32,strNewName.toStdString().c_str(),strNewName.size());
            strncpy((char *)pdu->caMSg,strCurPath.toStdString().c_str(),strCurPath.size());
            TcpClient::getInstance().getTcpSocket().write((char *)pdu,pdu->uiPDULen);
            free(pdu);
            pdu=NULL;
        }
    }
}

void Book::enterDir(const QModelIndex &index)
{
    QString strDirName=index.data().toString();
    QString strCurPath=TcpClient::getInstance().curPath();
    qDebug()<<"strDirName"<<strDirName;
    qDebug()<<"strCurPath"<<strCurPath;
    PDU *pdu=mkPDU(strCurPath.size()+1);

    pdu->uiMsgType=ENUM_MSG_TYPE_ENTER_DIR_REQUEST;
    strncpy(pdu->caData,strDirName.toStdString().c_str(),strDirName.size());
    strncpy((char *)pdu->caMSg,strCurPath.toStdString().c_str(),strCurPath.size());

    qDebug()<<pdu->caData;
    qDebug()<<(char *)pdu->caMSg;
    TcpClient::getInstance().getTcpSocket().write((char *)pdu,pdu->uiPDULen);
    free(pdu);
    pdu=NULL;
}

void Book::returnPre()
{
    QString strCurPath=TcpClient::getInstance().curPath();
    QString strRootPath="./"+TcpClient::getInstance().loginName();
    if(strCurPath==strRootPath)
    {
        QMessageBox::warning(this,"返回上一级","已经是根目录了，无法返回！");
    }
    else
    {   //index为strCurPath从后往前找的第一个/的下标（下标左往右，从0开始）
        //remove,从index开始移除字符串，后面为移除的长度
        int index=strCurPath.lastIndexOf('/');
        strCurPath.remove(index,strCurPath.size()-index);
        qDebug()<<"strCurPath"<<strCurPath;
        TcpClient::getInstance().setCurPath(strCurPath);
        flushFile();
    }
}

void Book::uploadFile()
{
    QString strCurPath=TcpClient::getInstance().curPath();
    //展示上传文件对话框，获取上传的文件路径
    m_strUploadFilePath=QFileDialog::getOpenFileName();
    qDebug()<<"m_strUploadFilePath"<<m_strUploadFilePath;
    if(m_strUploadFilePath.isEmpty())
    {
        QMessageBox::warning(this,"上传文件","请选择文件后再上传");
    }
    else
    {
        int index=m_strUploadFilePath.lastIndexOf('/');
        //right() 是 QString 的一个方法，用于从字符串的右边（即从末尾开始）截取指定长度的子字符串。它的参数是要截取的长度。
        QString strFileName=m_strUploadFilePath.right(m_strUploadFilePath.size()-index-1);
        qDebug()<<"strFileName"<<strFileName;

        QFile file(m_strUploadFilePath);
        qint64 fileSize=file.size();
        PDU *pdu=mkPDU(strCurPath.size()+1);
        pdu->uiMsgType=ENUM_MSG_TYPE_UPLOAD_FILE_REQUEST;
        memcpy((char *)pdu->caMSg,strCurPath.toStdString().c_str(),strCurPath.size());
        sprintf(pdu->caData,"%s %lld",strFileName.toStdString().c_str(),fileSize);
        //pdu->caData = QString("%1 %2").arg(strFileName).arg(fileSize).toStdString();等价上面
        TcpClient::getInstance().getTcpSocket().write((char *)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;

        //定时器开始运行，每隔 1000 毫秒（即 1 秒）会触发一次 timeout() 信号
        m_pTimer->start(1000);
    }
}

void Book::download()
{
    QString strCurPath=TcpClient::getInstance().curPath();
    QListWidgetItem *pItem=m_pBookListW->currentItem();
    if(pItem==NULL)
    {
        QMessageBox::warning(this,"下载文件","请选择文件后再下载");

    }
    else
    {
         QString fileName=pItem->text();
        //弹出一个对话框，用于选择下载文件保存的位置
        QString strSaveFilePath=QFileDialog::getSaveFileName(this,"下载文件",fileName);
        if(strSaveFilePath.isEmpty())
        {
            QMessageBox::warning(this,"下载文件","请选择文件保存的位置。");
            m_saveFilePath.clear();
        }
        else
        {
            m_saveFilePath=strSaveFilePath;
        }
        qDebug()<<"strSaveFilePath"<<strSaveFilePath;
        PDU *pdu=mkPDU(strCurPath.size()+1);
        pdu->uiMsgType=ENUM_MSG_TYPE_DOWNLOAD_FILE_REQUEST;
        strncpy(pdu->caData,fileName.toStdString().c_str(),fileName.size());
        strncpy((char *)pdu->caMSg,strCurPath.toStdString().c_str(),strCurPath.size());
        TcpClient::getInstance().getTcpSocket().write((char *)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;

    }
}

bool Book::getDownLoadStatus()
{
    return m_bDownLoad;
}

QString Book::getSaveFilePath()
{
    return m_saveFilePath;
}

QString Book::getShareFileName()
{
    return m_strShareFileName;
}



void Book::uploadFileData()
{
    m_pTimer->stop();
    QFile file(m_strUploadFilePath);
    if(!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::warning(this,"上传文件","打开文件失败");
        return;
    }
    qDebug()<<"要上传的文件已经打开";
    char *pBuffer=new char[4096];//每次传输4096个字符的效率最高
    qint64 ret=0;
    while(true)
    {   //从文件 file 中读取最多 4096 字节的数据并将其存储到 pBuffer 中。
        //ret变量存储的是实际读取的字节数
        //如果遇到文件末尾或者发生错误，则返回一个负值（例如 -1）。
        ret=file.read(pBuffer,4096);
        if(ret>0&&ret<=4096)
        {
            TcpClient::getInstance().getTcpSocket().write(pBuffer,ret);
        }
        else if(ret==0)
        {
            break;
        }
        else
        {
            QMessageBox::warning(this,"上传文件","上传文件失败：读取文件失败");
            break;
        }
    }

    file.close();
    delete []pBuffer;
    pBuffer=NULL;
}

QPushButton* Book::getFlushDirPB()
{
    return m_pFlushDirPB;
}

void Book::shareFile()
{
    QListWidgetItem *pItem = m_pBookListW->currentItem();
    if(NULL == pItem)
    {
        QMessageBox::warning(this, "分享文件", "请选择要分享的文件");
        return ;
    }
    m_strShareFileName = pItem->text();

    qDebug()<<"获取朋友列表";
    Friend *pFriend=OpeWidget::getInstance().getFriend();

    QListWidget *pFriendList=pFriend->getFriendList();
    for(int i=0;i<pFriendList->count();i++)
    {
        qDebug()<<"i:"<<pFriendList->item(i)->text();
    }

    ShareFile::getInstance().updateFriend(pFriendList);

    if(ShareFile::getInstance().isHidden())
    {
        ShareFile::getInstance().show();
    }
}

void Book::moveFile()
{
    qDebug()<<"开始移动文件";
    QListWidgetItem *pCurItem=m_pBookListW->currentItem();
    if(NULL!=pCurItem)
    {
        m_strMoveFileName=pCurItem->text();
        QString strCutPath=TcpClient::getInstance().curPath();
        m_strMoveFilePath=strCutPath+'/'+m_strMoveFileName;
        m_pSelectDirPB->setEnabled(true);
    }
    else
    {
        QMessageBox::warning(this,"移动文件","请选择要移动的文件");
    }
}

void Book::selectDestDir()
{
    QListWidgetItem *pCurItem=m_pBookListW->currentItem();
    if(NULL!=pCurItem)
    {
        QString strDestDir=pCurItem->text();
        QString strCutPath=TcpClient::getInstance().curPath();
        m_strDestDir=strCutPath+'/'+strDestDir;

        int srcLen=m_strMoveFilePath.size();
        int destLen=m_strDestDir.size();
        PDU *pdu=mkPDU(srcLen+destLen+2);
        pdu->uiMsgType=ENUM_MSG_TYPE_MOVE_FILE_REQUEST;
        //格式字符串 "%d %d %s" 中，两个 %d 之间有一个空格。这意味着 srcLen 和 destLen 之间会有一个空格。
        sprintf(pdu->caData,"%d %d %s",srcLen,destLen,m_strMoveFileName.toStdString().c_str());

        memcpy(pdu->caMSg,m_strMoveFilePath.toStdString().c_str(),srcLen);
        memcpy((char *)(pdu->caMSg)+(srcLen+1),m_strDestDir.toStdString().c_str(),destLen);

        qDebug()<<"pdu->caMSg"<<(char *)pdu->caMSg;
        qDebug()<<"fefe"<<(char *)(pdu->caMSg)+(srcLen+1);
        TcpClient::getInstance().getTcpSocket().write((char *)pdu,pdu->uiPDULen);
        free(pdu);
        pdu=NULL;
    }
    else
    {
        QMessageBox::warning(this,"移动文件","请选择目标文件夹");
    }
        m_pSelectDirPB->setEnabled(false);
}

