#include "abstractvideosurface.h"
#include <QDebug>

AbstractVideoSurface::AbstractVideoSurface(QObject* parent):
    QAbstractVideoSurface(parent)
{

}

bool AbstractVideoSurface::present(const QVideoFrame &frame)
{
    //摄像头拍到每一帧图片后会自动调用
    qDebug()<<"Presenting a new frame!";
    //摄像头拍到的图片，都以QVideoFrame类型传入当前函数，我们要做的是把他转换成QPixmap
    QVideoFrame fm = frame;
    fm.map(QAbstractVideoBuffer::ReadOnly);

    /*
     现在开始，将QVideoFrame转换成QPixmap
     我们应该：
     1、去QVideoFrame里面，寻找返回值为QPixmap，
    */
    QImage::Format format = fm.imageFormatFromPixelFormat(fm.pixelFormat());

    QImage image(fm.bits(),fm.width(),fm.height(),fm.bytesPerLine(),format);
    image = image.mirrored(1);
    emit sndImage(image);

}

QList<QVideoFrame::PixelFormat>
AbstractVideoSurface::supportedPixelFormats(QAbstractVideoBuffer::HandleType type) const
{
    Q_UNUSED(type);
    return QList<QVideoFrame::PixelFormat>()<<QVideoFrame::Format_BGR32;
}
