#include "livingroom.h"
#include "ui_livingroom.h"
#include "pack.h"
#include <QCamera>
#include <QVideoProbe>
#include <QTimer>
#include <QVideoFrame>
#include <QImage>
#include <QMessageBox>

static QImage qt_imageFromVideoFrame(const QVideoFrame &frame)
{
    if (!frame.isValid()) return {};
    QVideoFrame f(frame);
    if (!f.map(QAbstractVideoBuffer::ReadOnly)) return {};

    const uchar *src = f.bits();
    const int w = f.width(), h = f.height();
    QImage img;

    qDebug() << "QVideoFrame pixel format:" << f.pixelFormat();

    switch (f.pixelFormat()) {
    case QVideoFrame::Format_YUYV: {
        img = QImage(w, h, QImage::Format_RGB888);
        for (int y = 0; y < h; ++y) {
            const uchar *line = src + y * f.bytesPerLine();
            uchar *dst = img.scanLine(y);
            for (int x = 0; x < w; x += 2) {
                int y0 = line[0], u = line[1], y1 = line[2], v = line[3];
                line += 4;
                int c = y0 - 16, d = u - 128, e = v - 128;
                int r = qBound(0, (298 * c           + 409 * e + 128) >> 8, 255);
                int g = qBound(0, (298 * c - 100 * d - 208 * e + 128) >> 8, 255);
                int b = qBound(0, (298 * c + 516 * d           + 128) >> 8, 255);
                *dst++ = r; *dst++ = g; *dst++ = b;
                c = y1 - 16;
                r = qBound(0, (298 * c           + 409 * e + 128) >> 8, 255);
                g = qBound(0, (298 * c - 100 * d - 208 * e + 128) >> 8, 255);
                b = qBound(0, (298 * c + 516 * d           + 128) >> 8, 255);
                *dst++ = r; *dst++ = g; *dst++ = b;
            }
        }
        break;
    }
    case QVideoFrame::Format_RGB24:
        img = QImage(src, w, h, f.bytesPerLine(), QImage::Format_RGB888);
        break;
    case QVideoFrame::Format_RGB32:
    case QVideoFrame::Format_ARGB32:
        img = QImage(src, w, h, f.bytesPerLine(), QImage::Format_ARGB32);
        break;
    default:
        img = QImage();   // 其它格式再陆续补
        break;
    }
    f.unmap();
    return img.copy();   // detach 防止野指针
}


LivingRoom::LivingRoom(QTcpSocket* ptcpsocket, QString ownername, QString name,
                       bool isowner, QString roomid, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LivingRoom),
    m_ptcpsocket(ptcpsocket),
    m_owner_name(ownername),
    m_name(name),
    m_isowner(isowner),
    m_roomid(roomid)
{
    ui->setupUi(this);


    //关闭直播按钮
    connect(ui->pushButton_closeliving, &QPushButton::clicked,
            this, &LivingRoom::onLeave);

    // livingroom.cpp 构造函数
    connect(ui->pushButton_send_talk_information, &QPushButton::clicked,
            this, &LivingRoom::onSendChat);

    // livingroom.cpp 构造函数
    ui->pushButton_startliving->setVisible(m_isowner);   // 仅房主可见
    connect(ui->pushButton_startliving, &QPushButton::clicked,
            this, &LivingRoom::onStartLiving);

    connect(m_probe, &QVideoProbe::videoFrameProbed,
            [this](const QVideoFrame &frame) {
                QImage img = qt_imageFromVideoFrame(frame);
                if (!img.isNull()) presentFrame(img);
            });

    init_window();
}

LivingRoom::~LivingRoom()
{
    delete ui;
}

void LivingRoom::init_window()
{
    setWindowTitle(m_name);
    ui->label_roomid->setText(m_roomid);

    // === 统一显示画布 ===
    ui->label_camera->setMinimumSize(320, 240);   // 必须给尺寸
    ui->label_camera->setScaledContents(true);    // 允许缩放
    ui->label_camera->setStyleSheet("border:1px solid #aaa;"); // 可见边框

    // 用户列表初始值（保持原样）
    if (m_isowner) {
        ui->listWidget_allusername->addItem(new QListWidgetItem(m_name + QStringLiteral("(主播)")));
    } else {
        ui->listWidget_allusername->addItem(new QListWidgetItem(m_owner_name + QStringLiteral("(主播)")));
        ui->listWidget_allusername->addItem(new QListWidgetItem(m_name));
    }
}

void LivingRoom::add_user(const QString& name)
{
    ui->listWidget_allusername->addItem(new QListWidgetItem(name));
}

void LivingRoom::remove_user(const QString &leaveName)
{
    auto items = ui->listWidget_allusername->findItems(leaveName, Qt::MatchExactly);
    for (QListWidgetItem *it : items) {
        int row = ui->listWidget_allusername->row(it);
        ui->listWidget_allusername->takeItem(row);
        delete it;
    }
}


//显示消息
void LivingRoom::appendChat(const QString &nick, const QString &text)
{
    // 每条消息一行，格式：昵称: 内容
    ui->textEdit_talking_information->append(
                QString("<b>%1</b>: %2").arg(nick.toHtmlEscaped(), text.toHtmlEscaped()));
}

void LivingRoom::showRemoteFrame(const QImage &src)
{
    QImage scaled = src.scaled(ui->label_camera->size(),
                               Qt::KeepAspectRatio,
                               Qt::SmoothTransformation);
    ui->label_camera->setPixmap(QPixmap::fromImage(scaled));
}

void LivingRoom::onVideoFrame(const QString &from, const QByteArray &jpegBase64)
{
    if (from == m_name) return;          // 自己发的忽略
    QImage img;
    if (img.loadFromData(QByteArray::fromBase64(jpegBase64), "JPEG"))
    {
        qDebug() << "Received video frame from:" << from;
        showRemoteFrame(img);
    }
    else
    {
        qDebug() << "Failed to decode video frame from:" << from;
    }
}

void LivingRoom::onLeave()
{
    Pack pack;
    pack.set_type(TYPE_STREAMER_LEFT); // 使用一个新的消息类型
    pack.set_content(m_roomid);        // 房间号
    pack.set_content(m_name);          // 主播昵称

    qint64 wlen = m_ptcpsocket->write(pack.data());
    m_ptcpsocket->flush();

    // 停止摄像头
    if (m_camera) {
        m_camera->stop();
        delete m_camera;  m_camera = nullptr;
        delete m_probe;   m_probe  = nullptr;
    }

    ui->pushButton_startliving->setText("开始直播");
    ui->label_camera->clear();

    // 显示“主播暂时离开”的提示
    QMessageBox::information(this, "通知", QString("%1 暂时离开直播").arg(m_name));
}


//发送消息
void LivingRoom::onSendChat()
{
    QString text = ui->textEdit_talkinformation->toPlainText().trimmed();
    if (text.isEmpty()) return;

    Pack pack;
    pack.set_type(TYPE_CHAT_MSG);
    pack.set_content(m_roomid);
    pack.set_content(m_name);
    pack.set_content(text);

    m_ptcpsocket->write(pack.data());
    m_ptcpsocket->flush();

    ui->textEdit_talkinformation->clear();   // 清空输入区
}

// 打开摄像头
// ----------  最小改动测试版  ----------
void LivingRoom::onStartLiving()
{
    if (m_camera) {               // 停止直播
        m_camera->stop();
        delete m_camera;  m_camera = nullptr;
        delete m_probe;   m_probe  = nullptr;
        ui->pushButton_startliving->setText("开始直播");
        ui->label_camera->clear();
        return;
    }

    /* 1. 枚举摄像头 */
    QList<QCameraInfo> cameras = QCameraInfo::availableCameras();
    if (cameras.isEmpty()) {
        QMessageBox::critical(this, "错误", "没有可用摄像头");
        return;
    }
    qDebug() << "Using camera:" << cameras.first().description();

    /* 2. 初始化 QCamera 和 QVideoProbe */
    m_camera = new QCamera(cameras.first(), this);
    m_probe = new QVideoProbe(this);

    /* 3. 设置 QCameraViewfinder */
    QCameraViewfinder *vf = new QCameraViewfinder(ui->label_camera);
    vf->setFixedSize(ui->label_camera->size());
    vf->show();
    m_camera->setViewfinder(vf);

    /* 4. 连接 QVideoProbe */
    if (!m_probe->setSource(m_camera)) {
        QMessageBox::critical(this, "错误", "无法连接到摄像头");
        delete m_camera;  m_camera = nullptr;
        delete m_probe;   m_probe  = nullptr;
        return;
    }

    connect(m_probe, &QVideoProbe::videoFrameProbed,
            [this](const QVideoFrame &frame) {
                QImage img = qt_imageFromVideoFrame(frame);
                if (!img.isNull()) presentFrame(img);
            });

    /* 5. 启动摄像头 */
    m_camera->start();
    ui->pushButton_startliving->setText("停止直播");
}

void LivingRoom::captureFrame()
{
    if (!m_camera) return;
    // 实际用 probe 已拿到帧，这里留空即可
}

void LivingRoom::presentFrame(const QImage &src)
{
    // 1. 本地显示
    QImage show = src.scaled(ui->label_camera->size(),
                             Qt::KeepAspectRatio, Qt::SmoothTransformation);
    ui->label_camera->setPixmap(QPixmap::fromImage(show));

    // 2. 仅房主 + 跳帧
    if (!m_isowner) return;
    static qint64 last = 0;
    qint64 now = QDateTime::currentMSecsSinceEpoch();
    if (now - last < 100) return;          // 10 FPS 足够
    last = now;

    // 3. 翻转图像
    QImage flipped = src.mirrored(false, true);  // 水平不翻转，垂直翻转

    QImage small = flipped.scaledToWidth(640, Qt::SmoothTransformation);
    QByteArray jpeg;
    QBuffer buf(&jpeg);
    buf.open(QIODevice::WriteOnly);
    small.save(&buf, "JPEG", 50);          // 质量 50 一般 20~30 kB

    Pack pack;
    pack.set_type(TYPE_VIDEO_FRAME);
    pack.set_content(m_roomid);
    pack.set_content(m_name);
    pack.set_content(jpeg.toBase64());

    qDebug() << "Sending video frame, size:" << pack.data().size();

    m_ptcpsocket->write(pack.data());
}




