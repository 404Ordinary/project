#ifndef VIDEOPLAYER_H
#define VIDEOPLAYER_H

#include <QMainWindow>
#include <QLabel>
#include <QVBoxLayout>
#include <QWidget>
#include <QMediaPlayer>
#include <QAbstractVideoSurface> // 替换 QVideoSink 为 QAbstractVideoSurface
#include <QImage>               // 添加用于处理图像的头文件
#include "livingroom.h"

namespace Ui {
class VideoPlayer;
}

class VideoPlayer : public QMainWindow
{
    Q_OBJECT

public:
    // 构造函数和析构函数
    explicit VideoPlayer(LivingRoom *livingRoom, QWidget *parent = nullptr); // 添加 LivingRoom 参数
    ~VideoPlayer();

private slots:
    // 更新 QLabel 的槽函数
    void updateLabel(const QImage &image); // 修改为接收 QImage 类型

private:
    // UI 相关成员
    QLabel *label;          // 用于显示视频帧的 QLabel
    QWidget *centralWidget; // 主窗口的中心控件
    QVBoxLayout *layout;     // 布局管理器

    // 视频播放相关成员
    QMediaPlayer *mediaPlayer; // 视频播放器
    class VideoSurface *videoSurface; // 自定义的 QAbstractVideoSurface 实现
    QLabel *labelCamera;
};

#endif // VIDEOPLAYER_H
