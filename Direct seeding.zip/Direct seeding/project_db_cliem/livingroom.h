#ifndef LIVINGROOM_H
#define LIVINGROOM_H

#include <QWidget>
#include <QTcpSocket>
#include "pack.h"
#include <QCamera>
#include <QVideoProbe>
#include <QTimer>
#include <QImage>
#include <QBuffer>
#include <QDateTime>
#include <QCameraInfo>
#include <QCameraViewfinder>      // <-- 新增

namespace Ui {
class LivingRoom;
}

class LivingRoom : public QWidget
{
    Q_OBJECT

public:
    explicit LivingRoom(QTcpSocket* ptcpsocket, QString ownername, QString name,
                        bool isowner, QString roomid, QWidget *parent = nullptr);
    ~LivingRoom();

public:
    void init_window();

public:
    void add_user(const QString& name);
    void remove_user(const QString &leaveName);
    void flush_users(const QStringList &names);
    void appendChat(const QString &nick, const QString &text); // 把消息刷到界面
    void showRemoteFrame(const QImage &frame);
    void onVideoFrame(const QString &from, const QByteArray &jpegBase64);


private:
    Ui::LivingRoom *ui;
    QTcpSocket* m_ptcpsocket;
    QString m_owner_name;//拥有者姓名
    QString m_name;//用户姓名
    bool m_isowner;//拥有者
    QString m_roomid;//房间id
    QCamera *m_camera = nullptr;
    QVideoProbe *m_probe  = nullptr;
    QTimer *m_frameTimer = nullptr;
    void onCameraFrame(const QVideoFrame &frame);   // <-- 加上


private slots:
    void onLeave();          // 离开房间槽
    void onSendChat();               // 点击发送
    void onStartLiving();          // 点击“开始直播”
    void captureFrame();           // 定时抓帧
    void presentFrame(const QImage &frame); // 显示到 label

};

#endif // LIVINGROOM_H
