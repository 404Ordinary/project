#include "videoplayer.h"
#include <QMediaPlayer>
#include <QAbstractVideoSurface>
#include <QVideoFrame>
#include <QImage>
#include <QLabel>
#include <QVBoxLayout>

class VideoSurface : public QAbstractVideoSurface {
    Q_OBJECT
public:
    explicit VideoSurface(QObject *parent = nullptr) : QAbstractVideoSurface(parent) {}

    QList<QVideoFrame::PixelFormat> supportedPixelFormats(
            QAbstractVideoBuffer::HandleType handleType = QAbstractVideoBuffer::NoHandle) const override {
        return {QVideoFrame::Format_RGB32, QVideoFrame::Format_ARGB32};
    }

    bool present(const QVideoFrame &frame) override {
        if (frame.isValid()) {
            QVideoFrame cloneFrame(frame);
            cloneFrame.map(QAbstractVideoBuffer::ReadOnly);
            QImage image(cloneFrame.bits(),
                        cloneFrame.width(),
                        cloneFrame.height(),
                        QVideoFrame::imageFormatFromPixelFormat(cloneFrame.pixelFormat()));
            emit frameReady(image); // 发送图像信号
            cloneFrame.unmap();
        }
        return true;
    }

signals:
    void frameReady(const QImage &image); // 图像信号
};

// 构造函数
VideoPlayer::VideoPlayer(QWidget *parent)
    : QMainWindow(parent), label(new QLabel), centralWidget(new QWidget),
      layout(new QVBoxLayout), mediaPlayer(new QMediaPlayer), videoSurface(new VideoSurface)
{
    // 设置主窗口的中心控件
    setCentralWidget(centralWidget);

    // 配置 QLabel
    label->setAlignment(Qt::AlignCenter); // 居中显示
    label->setScaledContents(true);       // 自动缩放内容以适应 QLabel 大小

    // 将 QLabel 添加到布局中
    layout->addWidget(label);
    centralWidget->setLayout(layout);

    // 连接自定义视频表面的信号到槽函数
    connect(videoSurface, &VideoSurface::frameReady, this, &VideoPlayer::updateLabel);

    // 设置 QMediaPlayer 的输出为自定义视频表面
    mediaPlayer->setVideoOutput(videoSurface);

    // 示例：加载一个视频文件（请将路径替换为实际视频路径）
    mediaPlayer->setMedia(QUrl::fromLocalFile("path/to/your/video.mp4"));

    // 开始播放视频
    mediaPlayer->play();
}

// 析构函数
VideoPlayer::~VideoPlayer()
{
    delete label;         // 释放 QLabel
    delete layout;        // 释放布局管理器
    delete mediaPlayer;    // 释放 QMediaPlayer
    delete videoSurface;  // 释放自定义视频表面
}

// 槽函数：更新 QLabel 显示的视频帧
void VideoPlayer::updateLabel(const QImage &image)
{
    if (!image.isNull()) {
        label->setPixmap(QPixmap::fromImage(image)); // 更新 QLabel 的内容
    }
}
