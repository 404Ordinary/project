#ifndef USERINTERFACE_H
#define USERINTERFACE_H

#include <QWidget>
#include <QTcpSocket>
#include <QListWidgetItem>

namespace Ui {
class UserInterface;
}

class UserInterface : public QWidget
{
    Q_OBJECT

public:
    explicit UserInterface(QTcpSocket* ptcpsocket, QString name, QWidget *parent = nullptr);
    ~UserInterface();

public:
    void init_window();

public:
    void add_room_id(const QString& roomid);
    void flush_room_id();
    const QString get_joinroom_id();

public slots:
    void create_room();  // 点击创建房间的槽函数
    void join_room(); // 点击加入房间的槽函数
    void item_clicked(QListWidgetItem* item); // 点击房间号的槽函数

private:
    Ui::UserInterface *ui;
    QTcpSocket* m_ptcpsocket;
    QString m_join_room_id;
    QString m_name;
};

#endif // USERINTERFACE_H
