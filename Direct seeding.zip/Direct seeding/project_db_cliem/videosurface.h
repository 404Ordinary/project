#ifndef VIDEOSURFACE_H
#define VIDEOSURFACE_H


#include <QAbstractVideoSurface>
#include <QVideoSurfaceFormat>

class VideoSurface : public QAbstractVideoSurface {
    Q_OBJECT
public:
    explicit VideoSurface(QObject *parent = nullptr);

    QList<QVideoFrame::PixelFormat> supportedPixelFormats(
        QAbstractVideoBuffer::HandleType handleType = QAbstractVideoBuffer::NoHandle) const override;

    bool present(const QVideoFrame &frame) override;

signals:
    void frameAvailable(const QVideoFrame &frame);
};

#endif // VIDEOSURFACE_H
