#include "userinterface.h"
#include "ui_userinterface.h"
#include "pack.h"
#include <QMessageBox>

UserInterface::UserInterface(QTcpSocket* ptcpsocket, QString name, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::UserInterface),
    m_ptcpsocket(ptcpsocket),
    m_join_room_id(),
    m_name(name)
{
    ui->setupUi(this);

    init_window();
    this->setStyleSheet("QWidget {background-image: url(:/icons/4.png);}");
    // 点击创建房间
    connect(ui->pushButton_createroom, &QPushButton::clicked, this, &UserInterface::create_room);

    // 点击加入房间
    connect(ui->pushButton_joinroom, &QPushButton::clicked, this, &UserInterface::join_room);

    // 点击房间号
    connect(ui->listWidget_room, &QListWidget::itemClicked, this, &UserInterface::item_clicked);

    // 拉取房间号
    flush_room_id();
}

UserInterface::~UserInterface()
{
    delete ui;
}

void UserInterface::init_window()
{
    setWindowIcon(QIcon(":/icons/1.png"));
    setWindowTitle(m_name);

    return;
}

void UserInterface::add_room_id(const QString &roomid)
{
    ui->listWidget_room->addItem(new QListWidgetItem(roomid));

    return;
}

void UserInterface::flush_room_id()
{
    Pack pack;
    pack.set_type(TYPE_FLUSH_ROOM);

    m_ptcpsocket->write(pack.data());

    return;
}

const QString UserInterface::get_joinroom_id()
{
    return m_join_room_id;
}

// 点击创建房间的槽函数
void UserInterface::create_room()
{
   Pack pack;
   pack.set_type(TYPE_CREATE_ROOM);

   m_ptcpsocket->write(pack.data());

   return;
}

// 点击加入房间的槽函数
void UserInterface::join_room()
{
    if(m_join_room_id.isEmpty())
    {
        QMessageBox::warning(this, "警告", "请先选中房间号");
        return;
    }

    Pack pack;
    pack.set_type(TYPE_JOIN_ROOM);
    pack.set_content(m_join_room_id);

    m_ptcpsocket->write(pack.data());


    return;
}

// 点击房间号的槽函数
void UserInterface::item_clicked(QListWidgetItem *item)
{
    m_join_room_id = item->text();

    return;
}
