#ifndef ABSTRACTVIDEOSURFACE_H
#define ABSTRACTVIDEOSURFACE_H

#include <QObject>
#include <QAbstractVideoSurface>
#include <QList>
#include <QImage>

class AbstractVideoSurface : public QAbstractVideoSurface
{
    Q_OBJECT
public:
    AbstractVideoSurface(QObject* parent = nullptr);
    virtual bool present(const QVideoFrame &frame) override;

    //设置当前的类，能够支持图像处理格式，需要我们自己往里面添加支持的格式，所以需要重写
    //并且注意，在这个函数在构造函数的时候，默认被调用，所以我们自己是不需要调用它的

    virtual QList<QVideoFrame::PixelFormat>
    supportedPixelFormats(QAbstractVideoBuffer::HandleType type = QAbstractVideoBuffer::NoHandle) const override;

signals:
    void sndImage(QImage);
};

#endif // ABSTRACTVIDEOSURFACE_H
