#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpSocket>
#include "userinterface.h"
#include "livingroom.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

public:
    void init_network(); // 连接服务器

public:
    void init_window();

public:
    void user_register_back(const QStringList& content);  // 收到服务器返回的注册结果
    void user_login_back(const QStringList& content);  // 收到服务器返回的登录结果
    void user_create_room_back(const QStringList& content);  // 收到服务器返回的房间号
    void user_get_create_room_back(const QStringList& content);  // 其它登录成功的客户收到服务器返回的房间号
    void user_flush_room_back(const QStringList& content);  // 新登录成功的客户收到服务器返回的所有房间号
    void user_join_room_back(const QStringList& content);  // 收到服务器返回的加入房间的请求
    void user_get_newuser_back(const QStringList& content);  // 收到服务器返回给已经在直播间客户新加入者的姓名
    void user_flush_users_back(const QStringList& content);  // 收到服务器返回给新加入者已经在直播间所有客户（主播除外）的名字
    void user_leave_room_back(const QStringList &content);  // 收到服务器返回给新加入者已经在直播间所有客户（主播除外）的名字
    void user_streamer_left_back(const QStringList &content);

public slots:
    void registerbtn_clicked();   // 用户点击注册按钮的槽函数
    void loginbtn_clicked();  // 用户点击登录按钮的槽函数


public slots:
    void connect_ok();   // 连接服务器成功的槽函数
    void ready_read();   // 收到服务器发来信息的槽函数

private:
    Ui::Widget *ui;
    QTcpSocket* m_ptcpsocket;
    UserInterface* m_puserinterface;
    QString m_name;
    LivingRoom* m_plivingroom;
};
#endif // WIDGET_H
