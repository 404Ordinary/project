#include "widget.h"
#include "ui_widget.h"
#include <QMessageBox>
#include "pack.h"
#include "livingroom.h"
#include "ui_livingroom.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
    , m_ptcpsocket(new QTcpSocket(this))
    , m_puserinterface(NULL)
    , m_name()
{
    ui->setupUi(this);

    // 用户点击注册按钮
    connect(ui->pushButton_register, &QPushButton::clicked, this, &Widget::registerbtn_clicked);

    // 用户点击登录按钮
    connect(ui->pushButton_login, &QPushButton::clicked, this, &Widget::loginbtn_clicked);
    init_network();
    init_window();

    ui->lineEdit_pwd->setEchoMode(QLineEdit::Password);

    this->setStyleSheet("QWidget {background-image: url(:/icons/4.png);}");
}


//初始化Windows
void Widget::init_window()
{
    setWindowIcon(QIcon(":/icons/1.png"));
    setWindowTitle(m_name);

    return;
}

Widget::~Widget()
{
    delete ui;
}

// 连接服务器
void Widget::init_network()
{
    m_ptcpsocket->connectToHost("127.0.0.1", 8077);

    // 连接服务器成功
    connect(m_ptcpsocket, &QTcpSocket::connected, this, &Widget::connect_ok);

    // 收到服务器发来信息
    connect(m_ptcpsocket, &QTcpSocket::readyRead, this, &Widget::ready_read);
}

//收到服务器返回的注册结果
void Widget::user_register_back(const QStringList& content)
{
    unsigned char register_rst = content[0].toInt();

    switch (register_rst)
    {
    case 0:
        QMessageBox::information(this, "注册", "注册成功");
        break;

    case 1:
        QMessageBox::warning(this, "注册", "用户名长度不符合要求（[3, 12])");
        break;

    case 2:
        QMessageBox::warning(this, "注册", "用户名密码不符合要求（[3, 12])");
        break;

    case 3:
        QMessageBox::warning(this, "注册", "重复注册");
        break;

    case 4:
        QMessageBox::warning(this, "注册", "数据库错误");
        break;

    default:
        QMessageBox::warning(this, "注册", "未知错误");
        break;
    }

    return;
}

// 收到服务器返回的登录结果
void Widget::user_login_back(const QStringList &content)
{
    unsigned char login_rst = content[0].toInt();

    switch (login_rst)
    {
    case 0:
        QMessageBox::information(this, "登录", "登录成功");
        hide();
        m_puserinterface = new UserInterface(m_ptcpsocket, m_name);
        m_puserinterface->show();
        break;

    case 1:
        QMessageBox::warning(this, "登录", "用户名长度不符合要求（[3, 12])");
        break;

    case 2:
        QMessageBox::warning(this, "登录", "用户名密码不符合要求（[3, 12])");
        break;

    case 3:
        QMessageBox::warning(this, "登录", "用户名错误");
        break;

    case 4:
        QMessageBox::warning(this, "登录", "密码错误");
        break;

    case 5:
        QMessageBox::warning(this, "登录", "重复登录");
        break;

    case 6:
        QMessageBox::warning(this, "登录", "数据库错误");
        break;

    default:
        QMessageBox::warning(this, "注册", "未知错误");
        break;
    }

    return;
}

// 收到服务器返回的房间号
// 创建房间
void Widget::user_create_room_back(const QStringList &content)
{
    QString createroomid = content[0];
    m_puserinterface->add_room_id(createroomid);
    m_puserinterface->hide();

    m_plivingroom = new LivingRoom(m_ptcpsocket, m_name, m_name, true, createroomid);
    // 🔑 在这里连接
    connect(m_plivingroom, &QObject::destroyed,
            this, [&]{ m_plivingroom = nullptr; });
    m_plivingroom->show();
}

// 其它登录成功的客户收到服务器返回的房间号
void Widget::user_get_create_room_back(const QStringList &content)
{
    QString createroomid = content[0];
    m_puserinterface->add_room_id(createroomid);

    return;
}

// 新登录成功的客户收到服务器返回的所有房间号
void Widget::user_flush_room_back(const QStringList &content)
{
    for(auto createroom: content)
    {
        m_puserinterface->add_room_id(createroom);
    }

    return;
}

// 收到服务器返回的加入房间的请求
// 加入房间
void Widget::user_join_room_back(const QStringList &content)
{
    QString ownername = content[0];
    m_puserinterface->hide();

    m_plivingroom = new LivingRoom(m_ptcpsocket, ownername, m_name, false,
                                   m_puserinterface->get_joinroom_id());
    // 🔑 同样在这里连接
    connect(m_plivingroom, &QObject::destroyed,
            this, [&]{ m_plivingroom = nullptr; });
    m_plivingroom->show();
}

// 收到服务器返回给已经在直播间客户新加入者的姓名
void Widget::user_get_newuser_back(const QStringList &content)
{
     QString name = content[0];

     m_plivingroom->add_user(name);

     return;
}

// 收到服务器返回给新加入者已经在直播间所有客户（主播除外）的名字
void Widget::user_flush_users_back(const QStringList &content)
{

    for(auto othername: content)
    {
        m_plivingroom->add_user(othername);
    }

    return;
}

void Widget::user_leave_room_back(const QStringList &content)
{
    if (content.isEmpty()) return;
    QString leaveName = content[0];
    if (m_plivingroom) {
        qDebug() << "call remove_user(" << leaveName << ")";
        m_plivingroom->remove_user(leaveName);
    }
}

void Widget::user_streamer_left_back(const QStringList &content)
{
    QString streamerName = content[1];  // 获取主播昵称
    QMessageBox::information(this, "通知", QString("%1 暂时离开直播").arg(streamerName));
    // 不关闭直播窗口
}

// 用户点击注册按钮的槽函数`
void Widget::registerbtn_clicked()
{
    QString name = ui->lineEdit_name->text();
    QString pwd = ui->lineEdit_pwd->text();

    //    // 1.用户名长度不符合要求（[3, 12])
    //    if(name.length() > 12 || name.length() < 3)
    //    {
    //        QMessageBox::warning(this, "注册", "用户名长度不符合要求（[3, 12])");
    //        return;
    //    }

    //    // 2.用户名密码不符合要求([3, 12])
    //    if(pwd.length() > 12 || pwd.length() < 3)
    //    {
    //        QMessageBox::warning(this, "注册", "密码长度不符合要求（[3, 12])");
    //        return;
    //    }

    Pack pack;

    pack.set_type(TYPE_REGISETER);
    pack.set_content(name);
    pack.set_content(pwd);

    m_ptcpsocket->write(pack.data());

    return;
}

// 用户点击登录按钮的槽函数
void Widget::loginbtn_clicked()
{
    QString name = ui->lineEdit_name->text();
    QString pwd = ui->lineEdit_pwd->text();
    ui->lineEdit_pwd->setEchoMode(QLineEdit::Password);
    ui->lineEdit_pwd->setPlaceholderText("*");

    m_name = name;

    //    // 1.用户名长度不符合要求（[3, 12])
    //    if(name.length() > 12 || name.length() < 3)
    //    {
    //        QMessageBox::warning(this, "登录", "用户名长度不符合要求（[3, 12])");
    //        return;
    //    }

    //    // 2.用户名密码不符合要求([3, 12])
    //    if(pwd.length() > 12 || pwd.length() < 3)
    //    {
    //        QMessageBox::warning(this, "登录", "密码长度不符合要求（[3, 12])");
    //        return;
    //    }

    Pack pack;

    pack.set_type(TYPE_LOGIN);
    pack.set_content(name);
    pack.set_content(pwd);

    m_ptcpsocket->write(pack.data());

    return;
}

// 连接服务器成功的槽函数
void Widget::connect_ok()
{
    ui->pushButton_login->setEnabled(true);
    ui->pushButton_register->setEnabled(true);

    return;
}

// 收到服务器发来信息的槽函数
void Widget::ready_read()
{
    while (true )
    {
        // 先读序列化之后的包头（4个字节）
        QByteArray ba_header = m_ptcpsocket->read(4);
        if(ba_header.length() != 4)
        {
            return;
        }

        // 反序列化包头
        QDataStream stream_header(&ba_header, QIODevice::ReadOnly);
        unsigned int header = 0;
        stream_header >> header;

        // 再读序列化之后的包类型（1个字节）
        QByteArray ba_type = m_ptcpsocket->read(1);
        if(ba_type.length() != 1)
        {
            return;
        }

        // 反序列化包类型
        QDataStream stream_type(&ba_type, QIODevice::ReadOnly);
        unsigned char type = 0;
        stream_type >> type;

        // 再读取序列化之后的包内容
        QByteArray ba_content = m_ptcpsocket->read(header);
        if(ba_content.length() != header)
        {
            return;
        }

        // 反序列化包内容
        QDataStream stream_content(&ba_content, QIODevice::ReadOnly);
        QStringList contentlist;
        stream_content >> contentlist;

        switch (TYPE(type))
        {
        case TYPE_REGISETER://主持
            user_register_back(contentlist);
            break;

        case TYPE_LOGIN://登陆
            user_login_back(contentlist);
            break;

        case TYPE_CREATE_ROOM://创建房间
            user_create_room_back(contentlist);
            break;

        case TYPE_GET_CREATE_ROOM://创建房间
            user_get_create_room_back(contentlist);
            break;

        case TYPE_FLUSH_ROOM://刷新房间
            user_flush_room_back(contentlist);
            break;

        case TYPE_JOIN_ROOM://加入房间
            user_join_room_back(contentlist);
            break;

        case TYPE_GET_NEWUSER://获取新用户
            user_get_newuser_back(contentlist);
            break;

        case TYPE_FLUSH_USERS://刷新用户
            user_flush_users_back(contentlist);
            break;

        case TYPE_LEAVE_ROOM:          // 有人（正常/异常）离开
            user_leave_room_back(contentlist);
            break;

        case TYPE_CHAT_MSG:
            if (m_plivingroom) {
                QString nick = contentlist.value(0);
                QString text = contentlist.value(1);
                m_plivingroom->appendChat(nick, text);
            }
            break;

            // 在 LivingRoom 收到服务器推送的 parse 函数里
        case TYPE_VIDEO_FRAME:
            if (contentlist.size() >= 3 && m_plivingroom) {
                m_plivingroom->onVideoFrame(contentlist[1], contentlist[2].toLatin1());
            }
            break;

        case TYPE_STREAMER_LEFT:  // 处理主播已离开消息
            user_streamer_left_back(contentlist);
            break;


        default:
            break;
        }

    }

    return;
}


