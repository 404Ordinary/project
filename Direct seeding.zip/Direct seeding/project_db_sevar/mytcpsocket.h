#ifndef MYTCPSOCKET_H
#define MYTCPSOCKET_H

#include <QTcpSocket>

class MyTcpSocket
{
public:
    MyTcpSocket(QTcpSocket* ptcpsocket);

public:
    QTcpSocket* get_tcpsocket();
    QByteArray read(qint64 maxlen);
    qint64 write(const QByteArray &data);
    void close();
    void clear_room();
    void flush();   // 添加这一行

public:
    void set_name(const QString& name);
    const QString& get_name();
    void set_create_room(const QString& createroom);
    const QString& get_create_room();
    void set_join_room(const QString& joinroom);
    const QString& get_join_room();


private:
    QTcpSocket* m_ptcpsocket;
    QString m_name;
    QString m_create_room;
    QString m_join_room;
};

#endif // MYTCPSOCKET_H

