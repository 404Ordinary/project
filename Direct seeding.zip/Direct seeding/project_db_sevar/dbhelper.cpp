#include "dbhelper.h"
#include <QDebug>
#include <QSqlError>
#include <QSqlQuery>

DbHelper::DbHelper():m_db(QSqlDatabase::addDatabase("QODBC"))
{

}

DbHelper::~DbHelper()
{

}

bool DbHelper::init_db()
{
    m_db.setDatabaseName("projectdb");

    if(!m_db.open())
    {
        m_error = m_db.lastError().text();
        return false;
    }

    m_error.clear();

    return true;
}

QString DbHelper::last_error()
{
    return m_error;
}

// 处理用户注册的逻辑
// 0.注册成功；1.用户名长度不符合要求（[3, 12])；2.用户名密码不符合要求（[3, 12])；3.重复注册；4.数据库错误。
int DbHelper::user_register(const QString &name, const QString &pwd)
{
    // 1.用户名长度不符合要求（[3, 12])
    if(name.length() > 12 || name.length() < 3)
    {
        return 1;
    }

    // 2.用户名密码不符合要求([3, 12])
    if(pwd.length() > 12 || pwd.length() < 3)
    {
        return 2;
    }

    QSqlQuery query;
    QString strsql = QString("select * from user where name='%1';").arg(name);

    // 4.数据库错误
    if(!query.exec(strsql))
    {
        return 4;
    }

    // 数据库里面已经有name
    if(query.next())
    {
        return 3;
    }

    strsql = QString("insert into user(name, pwd) values('%1', '%2');").arg(name).arg(pwd);
    if(!query.exec(strsql))
    {
        return 4;
    }

    return 0;
}

// 处理用户登录的逻辑
// 0.登录成功；1.用户名长度不符合要求（[3, 12])；2.用户名密码不符合要求（[3, 12])；3.用户名错误；4.密码错误；5.重复登录；6.数据库错误。
int DbHelper::user_logoin(const QString &name, const QString &pwd)
{
    // 1.用户名长度不符合要求（[3, 12])
    if(name.length() > 12 || name.length() < 3)
    {
        return 1;
    }

    // 2.用户名密码不符合要求([3, 12])
    if(pwd.length() > 12 || pwd.length() < 3)
    {
        return 2;
    }

    // 3.用户名错误
    QString strsql = QString("select * from user where name='%1';").arg(name);
    QSqlQuery query;
    if(!query.exec(strsql))
    {
        return 6;
    }
    // 用户名匹配上了
    if(query.next())
    {
       if(query.value("pwd").toString() == pwd)
       {
           return 0;
       }

       return 4;
    }

    return 3;
}
