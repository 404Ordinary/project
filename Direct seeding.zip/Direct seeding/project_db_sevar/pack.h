#ifndef PACK_H
#define PACK_H
#include <QStringList>

typedef enum en_type
{
    TYPE_REGISETER,//注册
    TYPE_LOGIN,//登录
    TYPE_CREATE_ROOM,//创建房间
    TYPE_GET_CREATE_ROOM,//创建房间
    TYPE_FLUSH_ROOM,//刷新房间
    TYPE_JOIN_ROOM,//加入房间
    TYPE_GET_NEWUSER,//获取新用户
    TYPE_FLUSH_USERS,//刷新用户
    TYPR_CLOSE_ROOM,//关闭直播
    TYPE_LEAVE_ROOM,
    TYPE_CHAT_MSG,// 新增聊天消息
    TYPE_VIDEO_FRAME,
    TYPE_STREAMER_LEFT
}TYPE;


class Pack
{
public:
    Pack();

public:
    void set_content(const QString& content);
    void set_type(TYPE(type));
    QByteArray data();
    void clear();

private:
    unsigned int m_header;
    unsigned char m_type;
    QStringList m_content;
};

#endif // PACK_H
