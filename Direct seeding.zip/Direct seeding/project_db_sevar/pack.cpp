#include "pack.h"
#include <QDataStream>

Pack::Pack()
{

}

// 设置包内容
void Pack::set_content(const QString& content)
{
    m_content.append(content);
    return;
}

// 设置包类型
void Pack::set_type(TYPE type)
{
    m_type = (unsigned char)type;

    return;
}

// 序列化整个包（包头，包类型，包内容）
QByteArray Pack::data()
{
    // 序列化包体
    QByteArray ba;
    QDataStream stream(&ba, QIODevice::WriteOnly);

    // 序列化包体
    stream << m_content;

    // 计算出包体序列化之后有多少个字节
    m_header = ba.length();

    // 序列化包头和包体
    QByteArray bax;
    QDataStream streamx(&bax, QIODevice::WriteOnly);

    streamx << m_header << m_type << m_content;

    return bax;
}

void Pack::clear()
{
    m_header = 0;
    m_type = 0;
    m_content.clear();
}
