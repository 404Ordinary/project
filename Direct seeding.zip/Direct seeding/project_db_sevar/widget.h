#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QVector>
#include "mytcpsocket.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

public:
    void init_db();  // 连接数据库
    void init_network();  // 监听网络

public:
    MyTcpSocket* find_mytcpsocket(QTcpSocket* ptcpsocket);

public:
    void user_register(MyTcpSocket* pmytcpsocket, const QStringList &content);  // 收到客户端发来的注册信息
    void user_login(MyTcpSocket* pmytcpsocket,  const QStringList &content);  // 收到客户端发来的登录信息
    void user_create_room(MyTcpSocket* pmytcpsocket,  const QStringList &content);  // 收到客户端发来的创建房间信息
    void user_flush_room(MyTcpSocket* pmytcpsocket,  const QStringList &content);  // 收到客户端发来的请求房间信息
    void user_join_room(MyTcpSocket* pmytcpsocket,  const QStringList &content);  // 收到客户端发来的加入房间信息
    void user_close_room(MyTcpSocket* pmytcpsocket,  const QStringList &content);  // 收到客户端发来的退出房间信息
    void user_chat_msg(MyTcpSocket *pmytcpsocket, const QStringList &content);
    void user_video_frame(MyTcpSocket *src, const QStringList &content);


public slots:
    void new_connection();   // 客户连接成功的槽函数
    void ready_read();      // 收到客户端发来信息的槽函数
    void dis_connected();   // 收到客户端关闭信息的槽函数

private:
    Ui::Widget *ui;
    QTcpServer* m_ptcpserver;
    QVector<MyTcpSocket*> m_mytcpsocket_vec;
    quint32 m_create_room_id;
};
#endif // WIDGET_H
