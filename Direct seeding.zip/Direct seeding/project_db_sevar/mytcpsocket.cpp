#include "mytcpsocket.h"

MyTcpSocket::MyTcpSocket(QTcpSocket* ptcpsocket):
    m_name(),
    m_create_room(),
    m_join_room()
{
    m_ptcpsocket = ptcpsocket;
}

QTcpSocket *MyTcpSocket::get_tcpsocket()
{
    return m_ptcpsocket;
}

QByteArray MyTcpSocket::read(qint64 maxlen)
{
    return m_ptcpsocket->read(maxlen);
}

qint64 MyTcpSocket::write(const QByteArray &data)
{
    return m_ptcpsocket->write(data);
}

void MyTcpSocket::close()
{
    return m_ptcpsocket->close();
}

void MyTcpSocket::clear_room()
{
    m_create_room.clear();   // 如果你是房主，也一并清掉
    m_join_room.clear();     // 加入者只清这项即可
}

void MyTcpSocket::flush()
{
     m_ptcpsocket->flush();   // 直接调用底层 QTcpSocket 的 flush
}

void MyTcpSocket::set_name(const QString &name)
{
    m_name = name;

    return;
}

const QString &MyTcpSocket::get_name()
{
    return m_name;
}

void MyTcpSocket::set_create_room(const QString &createroom)
{
    m_create_room = createroom;

    return;
}

const QString &MyTcpSocket::get_create_room()
{
    return m_create_room;
}

void MyTcpSocket::set_join_room(const QString &joinroom)
{
    m_join_room = joinroom;

    return;
}

const QString &MyTcpSocket::get_join_room()
{
    return m_join_room;
}

