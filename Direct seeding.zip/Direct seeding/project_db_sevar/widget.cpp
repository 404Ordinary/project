#include "widget.h"
#include "ui_widget.h"
#include "dbhelper.h"
#include <QMessageBox>
#include <QTcpSocket>
#include "pack.h"
#include "mytcpsocket.h"
#include <QThread>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
    , m_ptcpserver(new QTcpServer(this))
    , m_mytcpsocket_vec()
    , m_create_room_id(0)
{
    ui->setupUi(this);

    init_db();

    init_network();
}

Widget::~Widget()
{
    delete ui;
}

// 连接数据库
void Widget::init_db()
{
    if(!DbHelper::get_instance().init_db())
    {
        QMessageBox::warning(this, "连接数据失败:", DbHelper::get_instance().last_error());

        exit(1);
    }

    return;
}

void Widget::init_network()
{
    if(!m_ptcpserver->listen(QHostAddress::Any, 8077))
    {
        QMessageBox::warning(this, "监听", "监听套接字失败");
        return;
    }

    // 客户连接成功
    connect(m_ptcpserver, &QTcpServer::newConnection, this, &Widget::new_connection);
}


MyTcpSocket *Widget::find_mytcpsocket(QTcpSocket* ptcpsocket)
{
    for(auto pmytcpsocket: m_mytcpsocket_vec)
    {
        if(pmytcpsocket->get_tcpsocket() == ptcpsocket)
        {
            return pmytcpsocket;
        }
    }

    return NULL;
}

// 收到客户端发来的注册信息
void Widget::user_register(MyTcpSocket* pmytcpsocket, const QStringList &content)
{
    QString name = content[0];
    QString pwd = content[1];

    int register_rst = DbHelper::get_instance().user_register(name, pwd);

    Pack pack;
    pack.set_type(TYPE_REGISETER);
    pack.set_content(QString::number(register_rst));

    pmytcpsocket->write(pack.data());

    return;
}

// 收到客户端发来的登录信息
void Widget::user_login(MyTcpSocket* pmytcpsocket, const QStringList &content)
{
    QString name = content[0];
    QString pwd = content[1];

    int login_rst = DbHelper::get_instance().user_logoin(name, pwd);

    // 如果登录成功，判断用户是否重复登录
    if(0 == login_rst)
    {
        for(auto pmytcpsocket: m_mytcpsocket_vec)
        {
            if(pmytcpsocket->get_name() == name)
            {
                login_rst = 5;
            }
        }
    }
    // 如果是第一次登录
    if(0 == login_rst)
    {
        pmytcpsocket->set_name(name);
    }


    Pack pack;
    pack.set_type(TYPE_LOGIN);
    pack.set_content(QString::number(login_rst));

    pmytcpsocket->write(pack.data());

    return;
}

// 收到客户端发来的创建房间信息
void Widget::user_create_room(MyTcpSocket *pmytcpsocket, const QStringList &content)
{
    qDebug() << "SRV enter user_create_room content=" << content;

    // 给创建者返回房间号
    Pack pack;
    pack.set_type(TYPE_CREATE_ROOM);
    pack.set_content(QString::number(++m_create_room_id));

    pmytcpsocket->set_create_room(QString::number(m_create_room_id));
    pmytcpsocket->write(pack.data());
    pmytcpsocket->flush();   // 立即发出

    // 给所有其他登录用户推送新房间号
    pack.clear();
    pack.set_type(TYPE_GET_CREATE_ROOM);
    pack.set_content(QString::number(m_create_room_id));
    for (auto ps : m_mytcpsocket_vec)
        if (ps != pmytcpsocket && !ps->get_name().isEmpty()) {
            ps->write(pack.data());
            ps->flush();
    }
}

// 收到客户端发来的请求房间信息
void Widget::user_flush_room(MyTcpSocket *pmytcpsocket, const QStringList &content)
{
    Pack pack;
    pack.set_type(TYPE_FLUSH_ROOM);

    for(auto pothermytcpsocket: m_mytcpsocket_vec)
    {
        if(!pothermytcpsocket->get_create_room().isEmpty())
        {
            pack.set_content(pothermytcpsocket->get_create_room());
        }
    }

    pmytcpsocket->write(pack.data());

    return;
}

// 收到客户端发来的加入房间信息
void Widget::user_join_room(MyTcpSocket *pmytcpsocket, const QStringList &content)
{
    QString joinroomid = content[0];


    // 返回给新加入者主播的名字
    Pack pack;
    pack.set_type(TYPE_JOIN_ROOM);

    for(auto pothermytcpsocket: m_mytcpsocket_vec)
    {
        if(pothermytcpsocket->get_create_room() == joinroomid)  // 找到房主
        {
            pack.set_content(pothermytcpsocket->get_name());  // 记录房主的名字
        }
    }

    pmytcpsocket->write(pack.data());


    // 返回给已经在直播间的所有用户新加进直播间用户的名字
    pack.clear();
    pack.set_type(TYPE_GET_NEWUSER);
    pack.set_content(pmytcpsocket->get_name());

    for(auto pothermytcpsocket: m_mytcpsocket_vec)
    {
        // 和加入者在同一个直播间
        if((pothermytcpsocket->get_create_room() == joinroomid) ||
                (pothermytcpsocket->get_join_room() == joinroomid))
        {
            pothermytcpsocket->write(pack.data());
        }
    }



    // 返回给新加入者同直播间其他所有用户（不含主播）的名字
    pack.clear();
    pack.set_type(TYPE_FLUSH_USERS);

    for(auto pothermytcpsocket: m_mytcpsocket_vec)
    {
        // 和加入者在同一个直播间
        if(pothermytcpsocket->get_join_room() == joinroomid)
        {
            pack.set_content(pothermytcpsocket->get_name());
        }
    }

    pmytcpsocket->write(pack.data());

    pmytcpsocket->set_join_room(joinroomid);

    return;
}


// 收到客户端发来的退出房间信息
void Widget::user_close_room(MyTcpSocket *pmytcpsocket, const QStringList &content)
{
    qDebug() << "SRV enter user_close_room content=" << content;
    if (content.size() < 2) return;
    QString roomid = content[0];
    QString name   = content[1];

    /* 1. 先广播“主播暂时离开” */
    Pack pack;
    pack.set_type(TYPE_STREAMER_LEFT);
    pack.set_content(roomid);          // 房间号
    pack.set_content(name);            // 主播昵称
    for (auto ps : m_mytcpsocket_vec)
        if (ps->get_join_room() == roomid || ps->get_create_room() == roomid)
            ps->write(pack.data());

    /* 2. 清内存 */
    for (auto ps : m_mytcpsocket_vec)
        if (ps->get_join_room() == roomid && ps->get_name() == name)
            ps->clear_room();

    /* 3. 再广播最新完整列表（可选，留给客户端刷新用） */
    QStringList onlineNames;
    for (auto ps : m_mytcpsocket_vec)
        if (ps->get_join_room() == roomid || ps->get_create_room() == roomid)
            onlineNames << ps->get_name();

    pack.clear();
    pack.set_type(TYPE_FLUSH_USERS);
    pack.set_content(onlineNames.join(","));
    for (auto ps : m_mytcpsocket_vec)
        if (ps->get_join_room() == roomid || ps->get_create_room() == roomid)
            ps->write(pack.data());

    /* 4. 给离开者回 200 */
    pack.clear();
    pack.set_type(TYPR_CLOSE_ROOM);
    pack.set_content("200");
    pmytcpsocket->write(pack.data());
}

void Widget::user_chat_msg(MyTcpSocket *pmytcpsocket, const QStringList &content)
{
    if (content.size() < 3) return;
    QString roomid = content[0];
    QString nick   = content[1];
    QString text   = content[2];

    Pack pack;
    pack.set_type(TYPE_CHAT_MSG);
    pack.set_content(nick);
    pack.set_content(text);

    // 同房间全员广播（包括自己）
    for (auto ps : m_mytcpsocket_vec)
        if (ps->get_join_room() == roomid || ps->get_create_room() == roomid) {
            ps->write(pack.data());
            ps->flush();
        }
}

void Widget::user_video_frame(MyTcpSocket *src, const QStringList &content)
{
    if (content.size() < 3) return;

    QString room = content[0];                       // 房间号
    // content[1] 是发送者昵称，这里用不到
    QByteArray jpeg = QByteArray::fromBase64(content[2].toLatin1());

    Pack pack;
    pack.set_type(TYPE_VIDEO_FRAME);
    pack.set_content(content[0]);   // 房间号
    pack.set_content(content[1]);   // 发送者昵称
    pack.set_content(content[2]);   // 帧数据

    /* 给同房间的其它人转发 */
    for (auto ms : qAsConst(m_mytcpsocket_vec)) {
        if (ms == src) continue;                    // 不发给自己
        if (ms->get_join_room() == room || ms->get_create_room() == room)
            ms->write(pack.data());
    }
}

// 客户连接成功
void Widget::new_connection()
{
    QTcpSocket* ptcpsocket = m_ptcpserver->nextPendingConnection();

    MyTcpSocket* pmytcpsocket = new MyTcpSocket(ptcpsocket);

    m_mytcpsocket_vec.push_back(pmytcpsocket);

    // 收到客户端发来信息
    connect(pmytcpsocket->get_tcpsocket(), &QTcpSocket::readyRead, this, &Widget::ready_read);

    // 收到客户端关闭信息
    connect(pmytcpsocket->get_tcpsocket(), &QTcpSocket::disconnected, this, &Widget::dis_connected);


}

// 收到客户端发来信息的槽函数
void Widget::ready_read()
{
    QTcpSocket* ptcpsocket =(QTcpSocket*)sender();

    MyTcpSocket* pmytcpsocket = find_mytcpsocket(ptcpsocket);

    while (true )
    {
        // 先读序列化之后的包头（4个字节）
        QByteArray ba_header = pmytcpsocket->read(4);
        if(ba_header.length() != 4)
        {
            return;
        }

        // 反序列化包头
        QDataStream stream_header(&ba_header, QIODevice::ReadOnly);
        unsigned int header = 0;
        stream_header >> header;

        // 再读序列化之后的包类型（1个字节）
        QByteArray ba_type = pmytcpsocket->read(1);
        if(ba_type.length() != 1)
        {
            return;
        }

        // 反序列化包类型
        QDataStream stream_type(&ba_type, QIODevice::ReadOnly);
        unsigned char type = 0;
        stream_type >> type;

        // 再读取序列化之后的包内容
        QByteArray ba_content = pmytcpsocket->read(header);
        if(ba_content.length() != header)
        {
            return;
        }

        // 反序列化包内容
        QDataStream stream_content(&ba_content, QIODevice::ReadOnly);
        QStringList contentlist;
        stream_content >> contentlist;

        switch (TYPE(type))
        {
        case TYPE_REGISETER:
            user_register(pmytcpsocket, contentlist);
            break;

        case TYPE_LOGIN:
            user_login(pmytcpsocket, contentlist);
            break;

        case TYPE_CREATE_ROOM:
            user_create_room(pmytcpsocket, contentlist);
            break;

        case TYPE_FLUSH_ROOM:
            user_flush_room(pmytcpsocket, contentlist);
            break;

        case TYPE_JOIN_ROOM:
            user_join_room(pmytcpsocket, contentlist);
            break;

        case TYPR_CLOSE_ROOM://关闭直播
            user_close_room(pmytcpsocket,contentlist);
            break;

        case TYPE_CHAT_MSG:
            user_chat_msg(pmytcpsocket, contentlist);
            break;

        case TYPE_VIDEO_FRAME:
            user_video_frame(pmytcpsocket, contentlist);
            break;

        default:
            break;
        }

    }

    return;
}

// 收到客户端关闭信息的槽函数
void Widget::dis_connected()
{
    QTcpSocket* ptcpsocket =(QTcpSocket*)sender();

    MyTcpSocket* pmytcpsocket = find_mytcpsocket(ptcpsocket);

    m_mytcpsocket_vec.removeOne(pmytcpsocket);

    pmytcpsocket->close();

    delete pmytcpsocket;

    return;
}
