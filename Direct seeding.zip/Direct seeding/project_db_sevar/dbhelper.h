#ifndef DBHELPER_H
#define DBHELPER_H

#include <QSqlDatabase>

class DbHelper
{
private:
    DbHelper();
    DbHelper(const DbHelper&);
    ~DbHelper();

public:
    static DbHelper& get_instance()
    {
        static DbHelper instance;
        return instance;
    }

public:
    bool init_db();
    QString last_error();

public:
    int user_register(const QString& name,const QString& pwd);//处理注册逻辑
    int user_logoin(const QString& name,const QString& pwd);//处理登录逻辑

private:
    QSqlDatabase m_db;
    QString m_error;
};

#endif // DBHELPER_H
